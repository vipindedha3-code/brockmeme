/* ARC Signal Engine v1 — deterministic indicators on CLOSED Binance candles only.
   Educational, not investment advice. Never transmits keys or places orders. */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.ArcEngine = factory(); })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const EPS = 1e-12;
  const round = (x,n=2) => Number.isFinite(x) ? Number(x.toFixed(n)) : null;
  const mean = a => a.length ? a.reduce((p,c) => p+c,0)/a.length : NaN;
  function ema(values, period) {
    if (!values.length) return [];
    const k = 2/(period+1), out=[];
    let prev = values[0];
    for (const v of values) { prev = k*v + (1-k)*prev; out.push(prev); }
    return out;
  }
  function rsi(values, period=14) {
    if (values.length < period+2) return NaN;
    let gains=0,losses=0;
    for(let i=1;i<=period;i++){const d=values[i]-values[i-1]; gains+=Math.max(0,d); losses+=Math.max(0,-d);}
    let g=gains/period,l=losses/period;
    for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];g=(g*(period-1)+Math.max(d,0))/period;l=(l*(period-1)+Math.max(-d,0))/period;}
    if(g< EPS && l<EPS)return 50; if(l<EPS)return 100;return 100-100/(1+g/l);
  }
  function atr(candles, period=14) {
    if(candles.length<period+2)return NaN;
    const trs=[];
    for(let i=1;i<candles.length;i++){const c=candles[i],p=candles[i-1];trs.push(Math.max(c.h-c.l,Math.abs(c.h-p.c),Math.abs(c.l-p.c)));}
    let a=mean(trs.slice(0,period));for(let i=period;i<trs.length;i++)a=(a*(period-1)+trs[i])/period;return a;
  }
  function macd(closes) {
    if(closes.length<35) return {hist: NaN,prevHist:NaN};
    const a=ema(closes,12),b=ema(closes,26),diff=a.map((v,i)=>v-b[i]),signal=ema(diff,9),hist=diff.map((v,i)=>v-signal[i]);
    return {hist:hist.at(-1),prevHist:hist.at(-2)};
  }
  function adx(candles,period=14) {
    if(candles.length<period*3+1)return NaN;
    const tr=[],pd=[],md=[];
    for(let i=1;i<candles.length;i++){
      const c=candles[i],p=candles[i-1],up=c.h-p.h,down=p.l-c.l;
      tr.push(Math.max(c.h-c.l,Math.abs(c.h-p.c),Math.abs(c.l-p.c)));
      pd.push(up>down&&up>0?up:0);md.push(down>up&&down>0?down:0);
    }
    let t=tr.slice(0,period).reduce((a,b)=>a+b,0),plus=pd.slice(0,period).reduce((a,b)=>a+b,0),minus=md.slice(0,period).reduce((a,b)=>a+b,0),dx=[];
    const mkDx=()=>{const p=100*plus/Math.max(t,EPS),m=100*minus/Math.max(t,EPS);return 100*Math.abs(p-m)/Math.max(p+m,EPS);};
    dx.push(mkDx());
    for(let i=period;i<tr.length;i++){t=t-t/period+tr[i];plus=plus-plus/period+pd[i];minus=minus-minus/period+md[i];dx.push(mkDx());}
    let val=mean(dx.slice(0,period));for(let i=period;i<dx.length;i++)val=(val*(period-1)+dx[i])/period;return val;
  }
  function parseKlines(rows,now=Date.now()) {
    if(!Array.isArray(rows))throw Error('Invalid candle response');
    const c=rows.map(r=>({t:Number(r[0]),o:Number(r[1]),h:Number(r[2]),l:Number(r[3]),c:Number(r[4]),v:Number(r[5]),end:Number(r[6]),q:Number(r[7]),buys:Number(r[9])}));
    return c.filter(x=>x.end<=now-1000&&[x.t,x.o,x.h,x.l,x.c,x.v,x.end].every(Number.isFinite)&&x.c>0&&x.h>=x.l).sort((a,b)=>a.t-b.t);
  }
  function metrics(candles){
    if(candles.length<65)throw Error('Need at least 65 closed candles');
    const closes=candles.map(x=>x.c),cur=candles.at(-1),before=candles.at(-2),vol=mean(candles.slice(-21,-1).map(x=>x.v)),mac=macd(closes);
    const buyQuote=cur.buys*cur.c, total=cur.q;
    return {close:cur.c,t:cur.end,prevClose:before.c,ema9:ema(closes,9).at(-1),ema21:ema(closes,21).at(-1),ema50:ema(closes,50).at(-1),rsi:rsi(closes),atr:atr(candles),adx:adx(candles),macd:mac.hist,macdPrev:mac.prevHist,volRatio:cur.v/Math.max(vol,EPS),buyRatio:total>0?buyQuote/total:0.5,
      lastHigh:candles.at(-2).h,lastLow:candles.at(-2).l,changePct:100*(cur.c/before.c-1), candles:candles.slice(-25).map(x=>x.c)};
  }
  function evaluate(m1,m5,m15, funding=0, mode='standard') {
    const cfg={strict:{min:78,delta:30},standard:{min:70,delta:24},early:{min:63,delta:19}}[mode] || {min:70,delta:24};
    let long=0,short=0,why=[],risks=[];
    const add=(condition,l,s,positive,negative)=>{if(condition){long+=l; if(positive)why.push(positive);}else{short+=s;if(negative)why.push(negative);}};
    add(m15.ema21>m15.ema50,17,17,'15m trend bullish','15m trend bearish');
    add(m15.close>m15.ema50,10,10,'15m above trend average','15m below trend average');
    add(m5.ema9>m5.ema21,15,15,'5m fast EMA above slow EMA','5m fast EMA below slow EMA');
    add(m5.close>m5.ema21,12,12,'5m price holding above EMA21','5m price below EMA21');
    add(m5.macd>0,11,11,'MACD positive','MACD negative');
    if(m5.macd>m5.macdPrev&&m5.macd>0)long+=4;
    if(m5.macd<m5.macdPrev&&m5.macd<0)short+=4;
    if(m5.rsi>=52 && m5.rsi<=69)long+=11;
    if(m5.rsi>=31 && m5.rsi<=48)short+=11;
    if(m1.ema9>m1.ema21&&m1.close>m1.ema9)long+=10;
    if(m1.ema9<m1.ema21&&m1.close<m1.ema9)short+=10;
    if(m5.volRatio>=1.2){if(m5.close>m5.prevClose)long+=8;if(m5.close<m5.prevClose)short+=8;why.push('5m volume expanding');}
    if(m5.adx>=19){if(m5.close>m5.ema21)long+=8;else short+=8;}
    if(m5.close>m5.lastHigh)long+=4;
    if(m5.close<m5.lastLow)short+=4;
    if(m5.adx<16){long-=10;short-=10;risks.push('Weak trend / choppy market');}
    if(m5.volRatio<0.65){long-=7;short-=7;risks.push('Low relative volume');}
    if(m5.rsi>=75){long-=24;risks.push('Long overbought');}
    if(m5.rsi<=25){short-=24;risks.push('Short oversold');}
    const ext=(m5.close-m5.ema9)/Math.max(m5.atr,EPS);
    if(ext>1.6){long-=17;risks.push('Long entry is extended');}
    if(ext< -1.6){short-=17;risks.push('Short entry is extended');}
    if(Math.abs(funding)>=0.0015){risks.push('Elevated funding'); if(funding>0)long-=7;else short-=7;}
    long=Math.max(0,Math.min(100,long));short=Math.max(0,Math.min(100,short));
    const bullTrend=m15.ema21>m15.ema50 && m5.ema9>m5.ema21;
    const bearTrend=m15.ema21<m15.ema50 && m5.ema9<m5.ema21;
    let state='WAIT',score=Math.max(long,short),side='NEUTRAL';
    if(bullTrend&&long>=cfg.min&&long-short>=cfg.delta&&m5.adx>=16){state='BUY NOW';score=long;side='LONG';}
    else if(bearTrend&&short>=cfg.min&&short-long>=cfg.delta&&m5.adx>=16){state='SELL NOW';score=short;side='SHORT';}
    let plan=null;
    if(state!=='WAIT'&&Number.isFinite(m5.atr)&&m5.atr>0){
      const entry=m5.close,stop=state==='BUY NOW'?entry-1.5*m5.atr:entry+1.5*m5.atr;
      const risk=Math.abs(entry-stop);plan={entry,stop,target1:state==='BUY NOW'?entry+1.6*risk:entry-1.6*risk,target2:state==='BUY NOW'?entry+2.4*risk:entry-2.4*risk,atr:m5.atr};
    }
    return {state,side,score:Math.round(score),long:Math.round(long),short:Math.round(short),why:why.slice(0,7),risks,plan,
      trend15:bullTrend?'BULLISH':bearTrend?'BEARISH':'MIXED',m1,m5,m15,funding,mode,candleTime:m5.t};
  }
  return {ema,rsi,atr,macd,adx,parseKlines,metrics,evaluate};
});
