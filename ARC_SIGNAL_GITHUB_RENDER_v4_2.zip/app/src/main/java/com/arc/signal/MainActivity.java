package com.arc.signal;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.content.Context;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b){ super.onCreate(b);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);
  NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("arc_signals","ARC Signal Alerts",NotificationManager.IMPORTANCE_DEFAULT));
  web=new WebView(this); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  web.addJavascriptInterface(new Object(){@JavascriptInterface public void notifySignal(String title,String body){runOnUiThread(()->{
   Notification.Builder n=Build.VERSION.SDK_INT>=26?new Notification.Builder(MainActivity.this,"arc_signals"):new Notification.Builder(MainActivity.this);
   n.setSmallIcon(android.R.drawable.stat_notify_more).setContentTitle(title).setContentText(body).setAutoCancel(true);
   nm.notify((int)(System.currentTimeMillis()%100000),n.build());
  });}},"ArcNative");
  setContentView(web); web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
