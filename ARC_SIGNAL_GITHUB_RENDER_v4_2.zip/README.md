# ARC Signal v4.2 — GitHub Android build

This is an Android WebView app using the existing ARC Signal HTML and JavaScript engine from the prior working package. Live Binance Futures endpoints are accessed by the app directly; the app does not execute trades.

## Build on GitHub
1. Create a new GitHub repository, preferably private.
2. Upload **the contents of this ZIP to the repository root** (not the ZIP itself). GitHub web upload may not preserve hidden `.github` folders reliably: use GitHub Desktop, git CLI, or extract and verify `.github/workflows/build-apk.yml` appears.
3. Open **Actions → Build ARC Signal APK → Run workflow** (or push to `main`).
4. Wait for success. Download `ARC_SIGNAL_v4_2_APK` under **Artifacts**, or open **Releases → v4.2**.
5. The APK is signed with GitHub's *debug* key. If the installed app uses the same package ID with a different signing certificate, Android will reject an in-place update. Back up any local app data before uninstalling the old app.

## Render download landing page
1. Replace `OWNER/REPOSITORY` in `public/index.html` with your actual GitHub owner and repo.
2. Connect the repository to Render as a **Static Site**, or deploy with `render.yaml` Blueprint.
3. Render hosts the download page; **GitHub Actions builds the APK** and GitHub Releases stores it. Render itself does not compile Android.

## Important limitations
- Notifications are triggered while the WebView app is active; there is **no persistent background market-monitoring service**.
- Existing in-app signal tracking is not independently verified as accurate trading P&L.
- This project was assembled from available web assets and has **not been compiled or tested on an Android phone in this environment**.
- This is a debug-signed build; for reliable upgrades and distribution use a persistent private release signing key in GitHub Secrets.
- Signals are not financial advice.
