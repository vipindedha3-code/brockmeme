BROCK Hunter v21 — PENDING-SAFE ULTRA-FAST PHANTOM

Key changes from v20:
- Fixes the “another Phantom trade is pending” deadlock shown in the activity log.
- Removes automatic Jupiter-browser fallback when a direct Phantom transaction is already pending.
- Only one real wallet approval can be active at a time; later PASS candidates are queued instead of opening duplicate trades.
- Stores the target-token balance before BUY/SELL and refreshes the real wallet on app resume to detect whether a trade actually settled even if the Phantom callback was missed.
- Stale unsigned prompts can be recovered after wallet verification; no fill is fabricated.
- Adds a visible pending-transaction status and CLEAR LOCAL PENDING recovery control.
- Cancel/reject clears the pending state immediately. Confirmed submissions reconcile the wallet before the next auto trade.
- No paper trading; Phantom still explicitly approves/signs every real transaction.

Important: clearing local pending state does not cancel an already-signed Solana transaction. The app refreshes the wallet first to reduce duplicate-order risk. Keep a small SOL balance for network fees.
