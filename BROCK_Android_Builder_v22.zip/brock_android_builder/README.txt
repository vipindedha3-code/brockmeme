BROCK Hunter v22 — PHANTOM SIGN + BROCK BROADCAST

Fixes the Phantom error: "This method is not supported".

The older build used Phantom signAndSendTransaction deep links, which Phantom now marks deprecated. v22 uses the supported signTransaction deeplink. BROCK builds the exact Jupiter swap, Phantom signs it after explicit user approval, and BROCK broadcasts the returned signed transaction through Solana RPC with failover/retry.

Real-only flow:
Scanner PASS -> safety PASS -> Jupiter swap built -> Phantom signTransaction -> user approves -> BROCK broadcasts -> on-chain settlement -> real wallet/P&L refresh.

No seed phrase or wallet signing key is stored by BROCK. Every real transaction still requires explicit Phantom approval.
