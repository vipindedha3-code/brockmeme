#!/usr/bin/env python3
import os, json, time, threading
from urllib.request import Request, urlopen
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DEX = "https://api.dexscreener.com"
RPC = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
BOT = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT = os.getenv("TELEGRAM_CHAT_ID", "5610595065")
INTERVAL = int(os.getenv("SCAN_INTERVAL_SECONDS", "60"))
ALERT_SCORE = float(os.getenv("ALERT_SCORE", "82"))
WATCH_SCORE = float(os.getenv("WATCH_SCORE", "70"))
PORT = int(os.getenv("PORT", "10000"))
UA = "BROCK-Meme-Hunter/1.3"

seen_alerts = {}

def num(v, default=0.0):
    try:
        return float(v)
    except Exception:
        return default

def http_json(url, method="GET", payload=None, timeout=15):
    body = None if payload is None else json.dumps(payload).encode()
    req = Request(
        url,
        data=body,
        method=method,
        headers={
            "User-Agent": UA,
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    )
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())

def rpc(method, params):
    res = http_json(
        RPC,
        "POST",
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params},
    )
    if res.get("error"):
        raise RuntimeError(str(res["error"]))
    return res.get("result")

def discover_tokens():
    found = {}
    for endpoint in (
        "/token-profiles/latest/v1",
        "/token-boosts/latest/v1",
        "/community-takeovers/latest/v1",
    ):
        try:
            rows = http_json(DEX + endpoint)
            if isinstance(rows, dict):
                rows = [rows]
            for row in rows[:100]:
                if str(row.get("chainId", "")).lower() != "solana":
                    continue
                mint = row.get("tokenAddress")
                if mint:
                    found[mint] = True
        except Exception as e:
            print("Discovery warning:", e, flush=True)
    return list(found.keys())[:60]

def get_pairs(mint):
    try:
        rows = http_json(f"{DEX}/token-pairs/v1/solana/{mint}")
        return rows if isinstance(rows, list) else []
    except Exception:
        return []

def onchain_risk(mint):
    out = {
        "ok": False,
        "mint_authority": None,
        "freeze_authority": None,
        "top1": None,
        "top5": None,
    }
    try:
        info = rpc("getAccountInfo", [mint, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        value = (info or {}).get("value") or {}
        parsed = (((value.get("data") or {}).get("parsed") or {}).get("info") or {})
        out["mint_authority"] = parsed.get("mintAuthority")
        out["freeze_authority"] = parsed.get("freezeAuthority")

        supply_res = rpc("getTokenSupply", [mint, {"commitment": "confirmed"}])
        supply = num(((supply_res or {}).get("value") or {}).get("amount"))

        largest = rpc("getTokenLargestAccounts", [mint, {"commitment": "confirmed"}])
        vals = (largest or {}).get("value") or []
        if supply > 0 and vals:
            pcts = [100 * num(x.get("amount")) / supply for x in vals]
            out["top1"] = pcts[0]
            out["top5"] = sum(pcts[:5])

        out["ok"] = True
    except Exception as e:
        out["error"] = str(e)
    return out

def telegram(text):
    if not BOT or not CHAT:
        print("Telegram not configured yet.", flush=True)
        return False
    try:
        http_json(
            f"https://api.telegram.org/bot{BOT}/sendMessage",
            "POST",
            {
                "chat_id": CHAT,
                "text": text,
                "disable_web_page_preview": True,
            },
        )
        return True
    except Exception as e:
        print("Telegram warning:", e, flush=True)
        return False

def evaluate(mint, pair):
    liq = num((pair.get("liquidity") or {}).get("usd"))
    mc = num(pair.get("marketCap")) or num(pair.get("fdv"))
    created = num(pair.get("pairCreatedAt"))
    age = (time.time() * 1000 - created) / 60000 if created else 999999

    tx5 = ((pair.get("txns") or {}).get("m5") or {})
    buys = int(tx5.get("buys") or 0)
    sells = int(tx5.get("sells") or 0)
    ratio = buys / max(1, sells)

    volume5 = num((pair.get("volume") or {}).get("m5"))
    volume1h = num((pair.get("volume") or {}).get("h1"))
    price5 = num((pair.get("priceChange") or {}).get("m5"))
    price1h = num((pair.get("priceChange") or {}).get("h1"))
    liq_mc = 100 * liq / mc if mc else 0

    risk = onchain_risk(mint)

    score = 0
    reject = []
    strengths = []
    warnings = []

    if not 2 <= age <= 360:
        reject.append("age outside target")
    if not 25000 <= mc <= 3000000:
        reject.append("market cap outside target")
    if liq < 15000:
        reject.append("liquidity too low")
    if liq_mc < 4:
        reject.append("weak liquidity/market-cap ratio")

    if risk["ok"]:
        if risk["mint_authority"]:
            reject.append("mint authority active")
        if risk["freeze_authority"]:
            reject.append("freeze authority active")
        if not risk["mint_authority"] and not risk["freeze_authority"]:
            score += 12
            strengths.append("mint/freeze authority disabled")

        if risk["top1"] is not None:
            if risk["top1"] <= 8:
                score += 8
                strengths.append("healthy top-holder concentration")
            elif risk["top1"] > 18:
                warnings.append("high top-holder concentration")
                score -= 6
    else:
        warnings.append("on-chain check unavailable")
        score -= 5

    if 7 <= age <= 120:
        score += 14
        strengths.append("early launch age")
    else:
        score += 5

    if 50000 <= mc <= 750000:
        score += 14
        strengths.append("early market-cap zone")
    else:
        score += 5

    score += 12 if liq >= 80000 else (9 if liq >= 30000 else 5)

    if liq_mc >= 15:
        score += 12
        strengths.append("strong liquidity/MC")
    elif liq_mc >= 8:
        score += 8
    else:
        score += 3

    if 1.25 <= ratio <= 3.5:
        score += 14
        strengths.append("healthy buy pressure")
    elif ratio > 1:
        score += 7

    tx_total = buys + sells
    if tx_total >= 80:
        score += 12
        strengths.append("strong 5m transactions")
    elif tx_total >= 30:
        score += 7

    if volume5 >= 5000:
        score += 7
    if liq and volume5 / liq >= 0.50:
        score += 6
        strengths.append("strong volume/liquidity")
    if mc and volume5 / mc >= 0.12:
        score += 5

    if 2 <= price5 <= 45:
        score += 5
    elif price5 > 80:
        score -= 8
        warnings.append("possible chase pump")

    score = max(0, min(100, round(score, 1)))

    return {
        "mint": mint,
        "score": score,
        "reject": reject,
        "strengths": strengths,
        "warnings": warnings,
        "age": age,
        "mc": mc,
        "liq": liq,
        "liq_mc": liq_mc,
        "buys": buys,
        "sells": sells,
        "ratio": ratio,
        "volume5": volume5,
        "volume1h": volume1h,
        "price5": price5,
        "price1h": price1h,
        "risk": risk,
        "url": pair.get("url", ""),
        "symbol": ((pair.get("baseToken") or {}).get("symbol") or "?"),
        "name": ((pair.get("baseToken") or {}).get("name") or "Unknown"),
    }

def make_alert(c):
    r = c["risk"]
    top1 = "n/a" if r["top1"] is None else f"{r['top1']:.1f}%"
    strengths = ", ".join(c["strengths"][:5]) or "balanced signal"
    warnings = ", ".join(c["warnings"][:3]) or "none"
    return (
        "BROCK MEME HUNTER\n\n"
        f"HIGH POTENTIAL - {c['score']}/100\n"
        f"{c['name']} ({c['symbol']})\n\n"
        f"Age: {c['age']:.0f}m\n"
        f"Market Cap: ${c['mc']:,.0f}\n"
        f"Liquidity: ${c['liq']:,.0f}\n"
        f"Liquidity/MC: {c['liq_mc']:.1f}%\n"
        f"5m Volume: ${c['volume5']:,.0f}\n"
        f"Buys/Sells: {c['buys']}/{c['sells']} ({c['ratio']:.2f}x)\n"
        f"5m Price: {c['price5']:+.1f}%\n"
        f"Top holder: {top1}\n\n"
        f"Strengths: {strengths}\n"
        f"Warnings: {warnings}\n\n"
        f"Contract:\n{c['mint']}\n\n"
        f"DEX Screener:\n{c['url']}"
    )

def scan_once():
    tokens = discover_tokens()
    print(f"Discovered {len(tokens)} Solana token(s)", flush=True)

    candidates = []
    for mint in tokens:
        pairs = get_pairs(mint)
        if not pairs:
            continue
        pair = max(pairs, key=lambda p: num((p.get("liquidity") or {}).get("usd")))
        candidates.append((mint, pair))

    candidates.sort(
        key=lambda x: num((x[1].get("volume") or {}).get("m5")),
        reverse=True,
    )

    for mint, pair in candidates[:30]:
        c = evaluate(mint, pair)
        status = "REJECT" if c["reject"] else ("HIGH" if c["score"] >= ALERT_SCORE else ("WATCH" if c["score"] >= WATCH_SCORE else "IGNORE"))
        print(f"{status:<6} {c['score']:>5} {c['symbol']:<12} age={c['age']:.0f}m liq=${c['liq']:,.0f}", flush=True)

        if c["reject"] or c["score"] < ALERT_SCORE:
            continue

        last = seen_alerts.get(mint, 0)
        if time.time() - last < 1800:
            continue

        seen_alerts[mint] = time.time()
        telegram(make_alert(c))

class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = b"BROCK Meme Hunter is running\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass

def run_health_server():
    ThreadingHTTPServer(("0.0.0.0", PORT), HealthHandler).serve_forever()

def main():
    threading.Thread(target=run_health_server, daemon=True).start()
    print("BROCK Meme Hunter v1.3 started - alert only - no wallet/private key", flush=True)
    while True:
        started = time.time()
        try:
            scan_once()
        except Exception as e:
            print("Scan error:", repr(e), flush=True)
        time.sleep(max(5, INTERVAL - (time.time() - started)))

if __name__ == "__main__":
    main()
