BROCK Hunter v2 - Survival Mode

Features:
- Grok-bot inspired terminal dashboard
- Adaptive paper-trading engine using live public DEX Screener data
- Six strategy agents: HUNT, WHALE, MOMO, VOLT, REV, SHIELD
- Simulated balance, P&L, win rate, exposure, open positions and balance chart
- Self-tuning strategy weights after resolved paper trades
- Automatic paper cycles while the app is running
- Live trade links open Jupiter for user review and wallet confirmation
- No seed phrase/private key storage
- No autonomous real-money execution

This build is for simulation and analysis. Meme coins are highly speculative and can lose most or all value.
