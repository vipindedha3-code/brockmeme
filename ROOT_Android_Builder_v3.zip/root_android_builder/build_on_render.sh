#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
export ANDROID_SDK_ROOT="$ROOT/.android-sdk"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
java -version
if [ ! -x "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "Downloading Android command-line tools..."
  curl -fsSL "https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip" -o /tmp/android-tools.zip
  rm -rf /tmp/android-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  mkdir -p /tmp/android-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  unzip -q /tmp/android-tools.zip -d /tmp/android-tools
  cp -R /tmp/android-tools/cmdline-tools/. "$ANDROID_SDK_ROOT/cmdline-tools/latest/"
fi
SDKMANAGER="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
"$SDKMANAGER" "platforms;android-35" "build-tools;35.0.0" "platform-tools"
if [ ! -x "$ROOT/.gradle-dist/gradle-8.9/bin/gradle" ]; then
  echo "Downloading Gradle..."
  mkdir -p "$ROOT/.gradle-dist"
  curl -fsSL "https://services.gradle.org/distributions/gradle-8.9-bin.zip" -o /tmp/gradle.zip
  unzip -q /tmp/gradle.zip -d "$ROOT/.gradle-dist"
fi
export PATH="$ANDROID_SDK_ROOT/platform-tools:$ANDROID_SDK_ROOT/build-tools/35.0.0:$PATH"
"$ROOT/.gradle-dist/gradle-8.9/bin/gradle" --no-daemon --stacktrace assembleDebug
mkdir -p "$ROOT/public"
cp "$ROOT/app/build/outputs/apk/debug/app-debug.apk" "$ROOT/public/ROOT-v3.apk"
cat > "$ROOT/public/index.html" <<'HTML'
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:system-ui;background:#050708;color:#f1fff5;text-align:center;padding:52px 18px}a{display:inline-block;background:#8cffb0;color:#031008;text-decoration:none;font-weight:900;padding:14px 22px;border-radius:14px}</style></head><body><h1>ROOT v3 REAL MONEY</h1><p>Generative multi-agent system with Phantom real-money wallet, live Solana trading and verified ROOT-managed P&L.</p><p><a href="/ROOT-v3.apk">Download ROOT APK</a></p></body></html>
HTML
sha256sum "$ROOT/public/ROOT-v3.apk" | tee "$ROOT/public/SHA256.txt"
