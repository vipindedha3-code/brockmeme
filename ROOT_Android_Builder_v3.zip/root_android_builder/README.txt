ROOT Android Builder v2.1 MAX

Features:
- Full generative multi-agent orchestration when an OpenAI-compatible provider is configured.
- Dedicated crypto jury: Scout, Market, Security, Skeptic, Risk Manager, Final Judge.
- Live Solana candidate screening via public market feeds and Jupiter Shield.
- AUTO HUNT scans every 60s while the app is open.
- Trade Assist can automatically open the strongest qualifying Jupiter route after deterministic + generative gates pass.
- Real-money wallet signature is mandatory. ROOT never stores a Phantom seed/private signing key and does not silently approve trades.
- Six-hour duplicate-route suppression and one assisted route at a time.

Build on Render with build_on_render.sh. Output: public/ROOT-v2.apk
