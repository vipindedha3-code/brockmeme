ROOT v2 - CORE ONLINE

ROOT Core now works without an AI API key for local orchestration, Wikipedia research, HTTPS tools and a selective live Solana Meme Hunter. Optional OpenAI-compatible cloud AI can still be configured for generative multi-agent synthesis. API secrets are encrypted with Android Keystore. ROOT does not request device root/superuser access.


ROOT v3 REAL MONEY
- Non-custodial Phantom deep-link connection; ROOT never stores seed phrase/private signing key.
- Reads confirmed SOL + SPL balances and market values.
- Separates wallet equity delta from ROOT-managed trading P&L.
- Builds exact Jupiter swaps in-app, Phantom signs, ROOT broadcasts to Solana.
- Auto Hunt can prepare a qualifying real trade, but every real transaction requires explicit Phantom approval.
- Duplicate buys blocked when the mint already exists in the real wallet.
- New buys capped at 7.5% of verified wallet value and blocked when exposure is unpriced.
- 100% real sell controls available for detected non-core holdings.
- No profit guarantee; memecoins can lose most or all value.
