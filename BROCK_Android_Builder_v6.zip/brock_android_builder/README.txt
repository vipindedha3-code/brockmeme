BROCK Hunter v6 - Adaptive EDGE / Phantom Live Assist

Key upgrades:
- Phantom public-wallet connection retained; BROCK never requests seed phrase/private key.
- Real wallet top balance display retained.
- Adaptive EDGE score combines brain score, SHIELD, order-flow quality and liquidity/MC.
- Anti-FOMO/chase filtering and extreme buy/sell-ratio filtering.
- Adaptive entry threshold rises after losses/drawdown and relaxes only after strong paper evidence.
- Risk-adjusted paper sizing based on EDGE, SHIELD and current losing streak.
- Break-even protection, trailing profit protection, stale-trade exit and hard stop/TP.
- Loss-streak and max-drawdown tracking with defensive lock after severe paper deterioration.
- Live pre-flight now requires EDGE quality and blocks when the paper engine is in defensive lock.
- Live sizing now treats risk % as risk-at-stop rather than raw position size, while retaining strict caps.
- Real-money execution remains user-confirmed through Jupiter/Phantom; BROCK does not sign or broadcast transactions.

No strategy can guarantee profit. Paper-test and start with small amounts.

Build on Render using build_on_render.sh. Output: public/BROCK-Hunter-v6.apk
