BROCK Hunter Android v1

Purpose:
- Solana meme coin screening dashboard
- Read-only public whale-wallet scanning
- Manual-confirmation trade links to Jupiter
- BROCK v2 Render backend status / wake button

Security:
- Does not request or store wallet private keys or seed phrases.
- Does not auto-execute trades.

Render build:
1. Unzip this project.
2. Run: bash build_on_render.sh
3. Serve brock_android_builder/public with a web server.
