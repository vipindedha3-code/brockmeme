BROCK Hunter v28 - INSTANT TRADE + CAPITAL GUARD

Critical v28 changes:
- Adds a dedicated in-app INSTANT BUY & SELL panel. BROCK builds the exact Jupiter transaction directly; Phantom remains the final signer.
- Instant BUY supports 25%, 50%, or 100% of the current Capital Guard risk-sized amount. It cannot exceed the safe position-size, exposure, price-impact, liquidity, or wallet limits.
- Instant SELL supports 25%, 50%, or 100% of a selected real wallet position, routed to USDC with SOL fallback.
- Existing real positions also show one-tap SELL 25%, SELL 50%, and INSTANT SELL 100% controls.
- No Jupiter browser hop is required for the normal direct transaction path.
- Preserves the duplicate-buy lock: one real position per token, no averaging down, and re-entry only after a confirmed full exit plus cooldown.
- Keeps verified wallet-delta cost basis, exposure caps, transaction locks, stop-loss/take-profit/trailing protective exits, and the two-loss circuit breaker.
- No paper trading. BROCK never stores a seed phrase or private signing key. Every real transaction still requires explicit approval in Phantom.
- Instant execution reduces taps; it does not guarantee execution speed, fill price, or profit. Slippage, failed routes, congestion, rugs, and gaps remain possible.

This is a debug/sideload APK build.


v28 RECOVERY GUARD: on-chain balance-first open-position state, safe stale-lock repair, UNKNOWN exposure for unpriced holdings, Jupiter executable sell-quote pricing fallback, specific reconciliation culprit, FORCE RECONCILE button, and SELL availability preserved while BUY guards/circuit breakers are active.


BROCK v28 COPY MESH
- Watch up to 8 PUBLIC Solana leader wallet addresses. Never enter seed phrases/private keys.
- Detect confirmed leader BUY/SELL token balance changes via Solana RPC.
- Copy Score combines observed leader trust, multi-wallet consensus, BROCK EDGE, SHIELD, liquidity and signal freshness.
- A copied BUY is never blind: normal BROCK HUNT/WHALE/MOMO/VOLT/REV/SHIELD, Cognition Mesh, token safety, account guard, price-chase guard and position locks remain mandatory.
- If a qualifying copied entry is prepared, Phantom still requires explicit user approval/signature.
- Confirmed copied positions remember source leaders. When those source leaders exit, BROCK may automatically prepare a proportional/full SELL for Phantom approval.
- Default public-RPC polling is 15 seconds and cannot guarantee sub-second latency. An optional user-supplied low-latency Solana RPC URL can be configured locally.
- No profit guarantee. Copying profitable-looking wallets can still lose money, especially in illiquid memecoins.
