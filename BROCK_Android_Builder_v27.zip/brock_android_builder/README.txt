BROCK Hunter v27 - INSTANT TRADE + CAPITAL GUARD

Critical v27 changes:
- Adds a dedicated in-app INSTANT BUY & SELL panel. BROCK builds the exact Jupiter transaction directly; Phantom remains the final signer.
- Instant BUY supports 25%, 50%, or 100% of the current Capital Guard risk-sized amount. It cannot exceed the safe position-size, exposure, price-impact, liquidity, or wallet limits.
- Instant SELL supports 25%, 50%, or 100% of a selected real wallet position, routed to USDC with SOL fallback.
- Existing real positions also show one-tap SELL 25%, SELL 50%, and INSTANT SELL 100% controls.
- No Jupiter browser hop is required for the normal direct transaction path.
- Preserves the duplicate-buy lock: one real position per token, no averaging down, and re-entry only after a confirmed full exit plus cooldown.
- Keeps verified wallet-delta cost basis, exposure caps, transaction locks, stop-loss/take-profit/trailing protective exits, and the two-loss circuit breaker.
- No paper trading. BROCK never stores a seed phrase or private signing key. Every real transaction still requires explicit approval in Phantom.
- Instant execution reduces taps; it does not guarantee execution speed, fill price, or profit. Slippage, failed routes, congestion, rugs, and gaps remain possible.

This is a debug/sideload APK build.


v27 RECOVERY GUARD: on-chain balance-first open-position state, safe stale-lock repair, UNKNOWN exposure for unpriced holdings, Jupiter executable sell-quote pricing fallback, specific reconciliation culprit, FORCE RECONCILE button, and SELL availability preserved while BUY guards/circuit breakers are active.
