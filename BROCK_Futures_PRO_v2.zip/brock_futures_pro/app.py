import json, os, time, threading, urllib.request, urllib.parse, math
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime, timezone
from pathlib import Path

SYMBOLS={'BTCUSDT':'XBTUSD','ETHUSDT':'ETHUSD','SOLUSDT':'SOLUSD'}
LOCK=threading.Lock()
STATE={'mode':'PAPER_ONLY','source':'Kraken public spot OHLC (proxy; NOT futures)','signals':{},'last_scan':None,'errors':[],'status':'STARTING'}
INTERVALS={'15m':15,'1h':60}

def fetch(symbol,tf):
    pair=SYMBOLS[symbol]; params=urllib.parse.urlencode({'pair':pair,'interval':INTERVALS[tf]})
    req=urllib.request.Request('https://api.kraken.com/0/public/OHLC?'+params,headers={'User-Agent':'BROCK-Futures-Paper/2.0 (research dashboard)','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=12) as res: data=json.load(res)
    if data.get('error'):raise RuntimeError('; '.join(data['error']))
    key=next(k for k in data['result'] if k!='last')
    rows=data['result'][key][:-1]
    if len(rows)<210:raise RuntimeError('Insufficient closed candles')
    return [{'time':int(x[0]),'open':float(x[1]),'high':float(x[2]),'low':float(x[3]),'close':float(x[4]),'volume':float(x[6])} for x in rows]

def ema(v,p):
    x=sum(v[:p])/p; a=2/(p+1)
    for n in v[p:]:x=a*n+(1-a)*x
    return x

def rsi(v,p=14):
    d=[v[i]-v[i-1] for i in range(1,len(v))]
    g=sum(max(x,0) for x in d[:p])/p;l=sum(max(-x,0) for x in d[:p])/p
    for x in d[p:]:g=(g*(p-1)+max(x,0))/p;l=(l*(p-1)+max(-x,0))/p
    return 100 if l==0 else 100-100/(1+g/l)

def atr(rows,p=14):
    tr=[max(rows[i]['high']-rows[i]['low'],abs(rows[i]['high']-rows[i-1]['close']),abs(rows[i]['low']-rows[i-1]['close'])) for i in range(1,len(rows))]
    v=sum(tr[:p])/p
    for x in tr[p:]:v=(v*(p-1)+x)/p
    return v

def scan(symbol):
    h=fetch(symbol,'1h');m=fetch(symbol,'15m');hc=[x['close'] for x in h];mc=[x['close'] for x in m]
    e50,e200=ema(hc,50),ema(hc,200);m20,m50=ema(mc,20),ema(mc,50)
    rel=m[-1]['volume']/max(1e-10,sum(x['volume'] for x in m[-21:-1])/20)
    strength=rsi(mc); price=mc[-1];vol=atr(m)
    bull=e50>e200 and m20>m50 and price>m20 and 52<strength<68 and rel>=1.2
    bear=e50<e200 and m20<m50 and price<m20 and 32<strength<48 and rel>=1.2
    signal='LONG_CANDIDATE' if bull else 'SHORT_CANDIDATE' if bear else 'NO_TRADE'
    reasons=[f"1h EMA50 {'above' if e50>e200 else 'below'} EMA200",f"15m EMA20 {'above' if m20>m50 else 'below'} EMA50",f'15m RSI {strength:.1f}',f'Volume {rel:.2f}x 20-bar average']
    return {'signal':signal,'close':round(price,6),'rsi':round(strength,2),'relative_volume':round(rel,2),'atr_15m':round(vol,6),'trend':'UP' if e50>e200 else 'DOWN','reasons':reasons,'candle_close_utc':datetime.fromtimestamp(m[-1]['time']+900,timezone.utc).isoformat(),'source':'Kraken spot candles (not Binance futures)','data_status':'OK','note':'Research only. No orders, no leverage, no execution.'}

def worker():
    while True:
        errors=[]
        for symbol in SYMBOLS:
            try:
                result=scan(symbol)
                with LOCK:STATE['signals'][symbol]=result
            except Exception as e:
                errors.append(f'{symbol}: {type(e).__name__}: {str(e)[:160]}')
                with LOCK:STATE['signals'][symbol]={'signal':'DATA_UNAVAILABLE','data_status':'ERROR','note':'No signal. Source unavailable; previous data suppressed.'}
        with LOCK:
            STATE['last_scan']=datetime.now(timezone.utc).isoformat();STATE['errors']=errors;STATE['status']='OK' if not errors else ('PARTIAL' if len(errors)<len(SYMBOLS) else 'DATA_UNAVAILABLE')
        time.sleep(90)

class Handler(BaseHTTPRequestHandler):
    def respond(self,body,ctype='application/json',code=200,head=False):
        b=body.encode('utf-8');self.send_response(code);self.send_header('Content-Type',ctype+'; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers()
        if not head:self.wfile.write(b)
    def do_HEAD(self):self.route(True)
    def do_GET(self):self.route(False)
    def route(self,head):
        if self.path.split('?')[0]=='/api/status':
            with LOCK: d=json.dumps(STATE)
            self.respond(d,head=head)
        elif self.path.split('?')[0] in ('/','/index.html'):
            self.respond(Path(__file__).with_name('index.html').read_text(), 'text/html',head=head)
        elif self.path.split('?')[0]=='/health':
            self.respond(json.dumps({'alive':True,'market_data_status':STATE['status']}),head=head)
        else:self.respond(json.dumps({'error':'Not found'}),code=404,head=head)

if __name__=='__main__':
    threading.Thread(target=worker,daemon=True).start()
    ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT','10000'))),Handler).serve_forever()
