BROCK Hunter v17 - REAL EXECUTION MESH

Changes:
- Real trade execution is no longer blocked by advisory brain/EDGE/cognition scores.
- Hard execution gate is separated from BROCK recommendation.
- Hard gate checks mint/freeze authority, holder concentration, liquidity, market cap, age, liquidity/MC, extreme momentum and market-data verification.
- Phantom confirmation remains mandatory for every real BUY/SELL.
- Solana RPC failover updated to current mainnet endpoint + PublicNode + legacy fallback.
- RPC retry/backoff improved and on-chain token risk is cached for 10 minutes.
- On-chain token safety reduced from 3 RPC calls to 2 by reading supply from the parsed mint account.
- Phantom connection automatically enables BROCK real-trading controls; no paper mode is used.

No strategy guarantees profit. Real trades can lose money.
