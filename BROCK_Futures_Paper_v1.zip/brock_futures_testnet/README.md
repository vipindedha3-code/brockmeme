# BROCK Futures PRO — Paper Signal Service

**PAPER ONLY**. This service does not connect to an account, place orders, or simulate P&L. It publishes experimental directional candidates for BTCUSDT, ETHUSDT, and SOLUSDT using Binance public USDT-M futures candles. The previous basic RSI/EMA/volume filter did not demonstrate a reliable edge; these conditions are not validated as profitable.

## Run locally

```bash
python app.py
```

Open `http://localhost:10000/` to view JSON state. The service needs outbound HTTPS to `fapi.binance.com`. It uses only completed candles, refreshes every minute, and returns NO_TRADE when filters are not met. HTTP errors are recorded in `errors`.

## Render

Push these files into a NEW folder or repository with appropriate GitHub access. Create a separate Python Web Service; build command `echo ready`; start command `python app.py`; health path `/`; region Singapore. Do not overwrite BROCK Hunter services.

## Before enabling any execution

Add historical backtesting with fee/funding/slippage models, proper 15m pullback triggers, robust protective-order lifecycle, idempotency, position reconciliation, exchange filters, position sizing, drawdown kill switches, secrets management, and multiweek testnet verification. Live orders are intentionally not implemented.
