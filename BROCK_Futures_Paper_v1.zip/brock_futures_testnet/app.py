import json, os, time, urllib.request, threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer

SYMBOLS = ['BTCUSDT','ETHUSDT','SOLUSDT']
STATE = {'mode':'PAPER_ONLY','signals':{},'last_scan':None,'errors':[]}

def candles(symbol, interval, limit=240):
    url=f'https://fapi.binance.com/fapi/v1/klines?symbol={symbol}&interval={interval}&limit={limit}'
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'BROCK-Futures-Paper/1.0'}),timeout=15) as response:
        rows=json.load(response)
    return [{'close':float(r[4]),'volume':float(r[5]),'closed_at':int(r[6])} for r in rows[:-1]]

def ema(values, period):
    if len(values)<period:return None
    out=sum(values[:period])/period
    alpha=2/(period+1)
    for v in values[period:]:out=alpha*v+(1-alpha)*out
    return out

def rsi(values,period=14):
    if len(values)<period+2:return None
    changes=[values[i]-values[i-1] for i in range(1,len(values))]
    gains=[max(v,0) for v in changes]
    losses=[max(-v,0) for v in changes]
    g=sum(gains[:period])/period;l=sum(losses[:period])/period
    for i in range(period,len(changes)):
        g=(g*(period-1)+gains[i])/period;l=(l*(period-1)+losses[i])/period
    return 100 if l==0 else 100-100/(1+g/l)

def scan(symbol):
    h=candles(symbol,'1h'); m=candles(symbol,'15m')
    hc=[x['close'] for x in h];mc=[x['close'] for x in m]
    e50=ema(hc,50);e200=ema(hc,200);m20=ema(mc,20);m50=ema(mc,50)
    rv=m[-1]['volume']/(sum(x['volume'] for x in m[-21:-1])/20)
    strength=rsi(mc)
    bullish=e50>e200 and m20>m50 and mc[-1]>m20 and 52<strength<68 and rv>=1.2
    bearish=e50<e200 and m20<m50 and mc[-1]<m20 and 32<strength<48 and rv>=1.2
    return {'signal':'LONG_CANDIDATE' if bullish else 'SHORT_CANDIDATE' if bearish else 'NO_TRADE', 'close':mc[-1], 'rsi':round(strength,2),'relative_volume':round(rv,2),'candle_close_utc':datetime.fromtimestamp(m[-1]['closed_at']/1000,timezone.utc).isoformat(),'note':'Research-only candidate. No orders submitted.'}

def worker():
    while True:
        for symbol in SYMBOLS:
            try:STATE['signals'][symbol]=scan(symbol)
            except Exception as exc:STATE['errors']=(STATE['errors']+[f'{symbol}: {type(exc).__name__}: {exc}'])[-10:]
        STATE['last_scan']=datetime.now(timezone.utc).isoformat()
        time.sleep(60)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body=json.dumps(STATE,indent=2).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)

if __name__=='__main__':
    threading.Thread(target=worker,daemon=True).start()
    HTTPServer(('0.0.0.0',int(os.getenv('PORT','10000'))),Handler).serve_forever()
