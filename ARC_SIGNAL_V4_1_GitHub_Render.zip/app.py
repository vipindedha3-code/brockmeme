import json, os, sqlite3, time, urllib.request, urllib.error, statistics, math
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path

ROOT=Path(__file__).parent
BASE='https://fapi.binance.com'
DB=os.environ.get('SIGNAL_DB','/tmp/arc_signal_v41.sqlite3')
CACHE={}
def fetch(path,ttl=8):
    now=time.time()
    if path in CACHE and now-CACHE[path][0]<ttl:return CACHE[path][1]
    req=urllib.request.Request(BASE+path,headers={'User-Agent':'ARC-Signal/4.1','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=12) as res: data=json.load(res)
    CACHE[path]=(now,data);return data

def ema(values,n):
    if len(values)<n:return None
    e=sum(values[:n])/n;k=2/(n+1)
    for v in values[n:]:e=v*k+e*(1-k)
    return e

def rsi(values,n=14):
    if len(values)<n+1:return None
    diffs=[values[i]-values[i-1] for i in range(1,len(values))]
    gain=sum(max(x,0) for x in diffs[:n])/n;loss=sum(max(-x,0) for x in diffs[:n])/n
    for x in diffs[n:]:gain=(gain*(n-1)+max(x,0))/n;loss=(loss*(n-1)+max(-x,0))/n
    return 100 if loss==0 else 100-100/(1+gain/loss)

def atr(rows,n=14):
    if len(rows)<n+1:return None
    trs=[max(rows[i][2]-rows[i][3],abs(rows[i][2]-rows[i-1][4]),abs(rows[i][3]-rows[i-1][4])) for i in range(1,len(rows))]
    a=sum(trs[:n])/n
    for x in trs[n:]:a=(a*(n-1)+x)/n
    return a

def macd_hist(values):
    if len(values)<35:return None
    fast=slow=None; series=[]
    for i in range(len(values)):
        if i>=11:fast=ema(values[:i+1],12) if i==11 else fast+(2/13)*(values[i]-fast)
        if i>=25:slow=ema(values[:i+1],26) if i==25 else slow+(2/27)*(values[i]-slow)
        if fast is not None and slow is not None:series.append(fast-slow)
    signal=ema(series,9)
    return series[-1]-signal if signal is not None else None

def adx(rows,n=14):
    if len(rows)<2*n+1:return None
    tr=[];pdm=[];mdm=[]
    for i in range(1,len(rows)):
        h,l,ph,pl,pc=rows[i][2],rows[i][3],rows[i-1][2],rows[i-1][3],rows[i-1][4]
        up=h-ph;down=pl-l
        pdm.append(up if up>down and up>0 else 0)
        mdm.append(down if down>up and down>0 else 0)
        tr.append(max(h-l,abs(h-pc),abs(l-pc)))
    a=sum(tr[:n]);p=sum(pdm[:n]);m=sum(mdm[:n]);dx=[]
    for i in range(n-1,len(tr)):
        if i>=n:a=a-a/n+tr[i];p=p-p/n+pdm[i];m=m-m/n+mdm[i]
        plus=100*p/a if a else 0;minus=100*m/a if a else 0
        dx.append(100*abs(plus-minus)/(plus+minus) if plus+minus else 0)
    if len(dx)<n:return None
    val=sum(dx[:n])/n
    for x in dx[n:]:val=(val*(n-1)+x)/n
    return val

def init_db():
    with sqlite3.connect(DB) as c:c.execute('CREATE TABLE IF NOT EXISTS signals(symbol TEXT, candle INTEGER, direction TEXT, entry REAL, stop REAL, target REAL, score INTEGER, created INTEGER, PRIMARY KEY(symbol,candle,direction))')

def symbols():
    data=fetch('/fapi/v1/exchangeInfo',300)
    return sorted([s['symbol'] for s in data['symbols'] if s.get('status')=='TRADING' and s.get('contractType')=='PERPETUAL' and s.get('quoteAsset')=='USDT'])

def klines(symbol,interval,limit=150):
    raw=fetch(f'/fapi/v1/klines?symbol={symbol}&interval={interval}&limit={limit}',10)
    now=int(time.time()*1000)
    return [[int(x[0]),float(x[1]),float(x[2]),float(x[3]),float(x[4]),float(x[5]),int(x[6])] for x in raw if int(x[6])<now]

def analyze(symbol):
    if symbol not in symbols():raise ValueError('Symbol is not an active Binance USDT-M perpetual contract')
    k15=klines(symbol,'15m');k1h=klines(symbol,'1h');k5=klines(symbol,'5m',80);k1=klines(symbol,'1m',80)
    if min(len(k15),len(k1h))<65:raise ValueError('Insufficient completed candles')
    closes=[x[4] for x in k15];hour=[x[4] for x in k1h]
    e20,e50=ema(closes,20),ema(closes,50);h20,h50=ema(hour,20),ema(hour,50)
    rv=k15[-1][5]/(sum(x[5] for x in k15[-21:-1])/20 or 1)
    r=rsi(closes);m=macd_hist(closes);a=adx(k15);vol=atr(k15)
    direction='BULL' if e20>e50 and closes[-1]>e20 else 'BEAR' if e20<e50 and closes[-1]<e20 else 'MIXED'
    hdir='BULL' if h20>h50 and hour[-1]>h20 else 'BEAR' if h20<h50 and hour[-1]<h20 else 'MIXED'
    prevhigh=max(x[2] for x in k15[-21:-1]);prevlow=min(x[3] for x in k15[-21:-1]);price=closes[-1]
    long=(direction=='BULL' and hdir=='BULL' and r>=52 and r<=72 and m>0 and a>=20 and rv>=1.5 and price>prevhigh)
    short=(direction=='BEAR' and hdir=='BEAR' and r>=28 and r<=48 and m<0 and a>=20 and rv>=1.5 and price<prevlow)
    # Exclude moves already extended > 2 ATR above/below 20 EMA.
    if vol and abs(price-e20)>2*vol:long=short=False
    action='BUY NOW' if long else 'SELL NOW' if short else 'WAIT'
    entry=stop=target=None;rr=None
    if action!='WAIT' and vol:
        entry=price;stop=price-(1.5*vol) if long else price+(1.5*vol)
        target=price+(3*vol) if long else price-(3*vol)
        if target<=0:action='WAIT';entry=stop=target=None
        else:rr=2.0
    # A score is descriptive, not an entry instruction.
    score=round(min(100,25+15*(direction==hdir and direction!='MIXED')+15*(a>=20)+15*(rv>=1.5)+15*(abs(m)>0)+15*(action!='WAIT')))
    ticker=fetch(f'/fapi/v1/ticker/price?symbol={symbol}',5)
    ticker_ts=int(ticker.get('time',int(time.time()*1000)))
    now_ms=int(time.time()*1000)
    if now_ms-ticker_ts>30000:raise ValueError('Exchange price is stale')
    result={'symbol':symbol,'action':action,'score':score,'livePrice':float(ticker['price']),'quoteTime':ticker_ts,'close':price,'candleOpen':k15[-1][0],'candleClose':k15[-1][6],'volume':k15[-1][5],'relativeVolume':round(rv,2),'rsi':round(r,1),'adx':round(a,1),'macdHistogram':m,'atr':vol,'ema20':e20,'ema50':e50,'trend15':direction,'trend1h':hdir,'trend5':'BULL' if ema([x[4] for x in k5],20)>ema([x[4] for x in k5],50) else 'BEAR','trend1':'BULL' if ema([x[4] for x in k1],20)>ema([x[4] for x in k1],50) else 'BEAR','entry':entry,'stop':stop,'target':target,'riskReward':rr,'priceAction':[x[4] for x in k5[-35:]],'source':'Binance USDT-M REST /fapi/v1','paperOnly':True}
    if action!='WAIT':
        with sqlite3.connect(DB) as c:c.execute('INSERT OR IGNORE INTO signals VALUES(?,?,?,?,?,?,?,?)',(symbol,k15[-1][0],action,entry,stop,target,score,int(time.time())))
    return result

class Handler(BaseHTTPRequestHandler):
    def send(self,code,data,ctype='application/json'):
        b=json.dumps(data).encode() if ctype=='application/json' else data
        self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path);q=parse_qs(p.query)
        try:
            if p.path=='/api/symbols':return self.send(200,{'symbols':symbols()})
            if p.path=='/api/signal':return self.send(200,analyze(q.get('symbol',['ARCUSDT'])[0].upper()))
            if p.path=='/api/history':
                s=q.get('symbol',['ARCUSDT'])[0].upper()
                with sqlite3.connect(DB) as c:rows=c.execute('SELECT candle,direction,entry,stop,target,score,created FROM signals WHERE symbol=? ORDER BY candle DESC LIMIT 100',(s,)).fetchall()
                return self.send(200,{'symbol':s,'signals':[dict(zip(['candle','direction','entry','stop','target','score','recordedAt'],x)) for x in rows],'note':'Forward paper signal log only; no win rate is claimed until outcomes are evaluated.'})
            if p.path in ['/','/index.html']:
                return self.send(200,(ROOT/'index.html').read_bytes(),'text/html; charset=utf-8')
            if p.path=='/manifest.json':return self.send(200,(ROOT/'manifest.json').read_bytes(),'application/manifest+json')
            if p.path=='/health':return self.send(200,{'status':'ok','source':'Binance futures only; market API errors cause no signal'})
            return self.send(404,{'error':'not found'})
        except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,ValueError,KeyError) as e:
            self.send(503,{'error':str(e),'action':'DATA UNAVAILABLE','note':'Fail closed: no simulated or fallback spot prices.'})
        except Exception as e:
            self.send(500,{'error':str(e),'action':'DATA UNAVAILABLE'})
if __name__=='__main__':
    init_db();port=int(os.environ.get('PORT','8000'));print('ARC SIGNAL v4.1 listening on',port,flush=True);ThreadingHTTPServer(('0.0.0.0',port),Handler).serve_forever()
