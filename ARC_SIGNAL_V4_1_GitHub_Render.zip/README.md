# ARC SIGNAL Futures Intelligence V4.1

Deployable mobile-first web app / PWA with a searchable selector for all active Binance USDT-M perpetual pairs. Default ARCUSDT; switch to BTCUSDT, SOLUSDT or any supported pair. Install from mobile browser's **Add to Home Screen** menu. **This ZIP is not an Android APK**.

## Deploy on Render

1. Upload this ZIP's extracted contents into a new GitHub repository or folder (app.py, index.html, manifest.json, render.yaml).
2. Create a new Render Python web service, build command `echo ready`, start command `python app.py`, or use the Blueprint `render.yaml`.
3. Open the HTTPS service URL on Android and use Add to Home Screen.
4. Do not replace existing ARC V3/V4 services until tested.

## What is verified / what is not

- The backend fetches `/fapi/v1/exchangeInfo`, `/fapi/v1/klines`, and `/fapi/v1/ticker/price` from **Binance USD-M Futures**. It never silently substitutes spot prices or fake candles. If Binance blocks the Render region (HTTP 418/451/403), the app fails closed with `DATA UNAVAILABLE`.
- Indicators use **completed** 1m/5m/15m/1h candles. BUY/SELL requires 15m EMA20/50 alignment, matching 1h trend, RSI, MACD, ADX>=20, relative volume >=1.5x and 20-bar high/low breakout; extended moves >2 ATR are rejected. ATR-derived stop/target offers a *theoretical* 2:1 R/R before fees, slippage, liquidity, liquidation or funding; these can invalidate the trade.
- The indicator alignment score is not a calibrated win probability. There is **no claim of proven profitability**.
- Signal events are logged to SQLite (`SIGNAL_DB`). Render ephemeral storage will erase them on restart unless a persistent disk is configured. The log does **not** compute realized P&L or backtest performance.
- Automatic orders, push notifications, independent data-provider comparison and historical out-of-sample strategy backtesting are **not included**. Do not rely on it for live money until independently validated.

## Local smoke test

`python app.py` then open http://localhost:8000 .

## Security / reliability

No API keys or wallet credentials are needed. Public market data only. Price timestamp must be under 30 seconds old. If live data cannot be obtained, it will not issue a BUY/SELL. For production, add durable database, request throttling, instrument-specific tick-size rounding, websocket trade feed, bid/ask spread checks, and forward-test outcome tracking.
