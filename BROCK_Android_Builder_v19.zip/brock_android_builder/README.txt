BROCK Hunter v19 - AUTO EXECUTION ASSIST

Changes:
- Scanner can automatically act on a BROCK recommendation PASS after hard Jupiter safety passes.
- BROCK chooses the real funding asset from the connected wallet (SOL, USDC or USDT) instead of assuming SOL.
- BROCK gets an exact Jupiter Lite quote and builds the real swap transaction for the risk-sized amount.
- BROCK automatically opens Phantom's transaction approval screen; the user must still approve/sign.
- No seed phrase/private signing key is stored by BROCK and there is no silent/unattended wallet spending.
- Adds an auto-prompt cooldown to prevent repeated Phantom prompts.
- Adds configurable maximum slippage.
- Requires a small SOL network-fee reserve when spending USDC/USDT.
- A Phantom response signature is required before BROCK treats a direct trade as submitted; app resume alone no longer implies a fill.
- Existing manual EXECUTE NOW button uses the same direct Jupiter -> Phantom flow with Jupiter-page fallback.
- No paper mode. Real balance, exposure and P&L remain on-chain wallet derived.

Important: Auto Execution Assist means BROCK automatically prepares and presents a real trade for approval. Phantom approval remains mandatory for every real transaction. No strategy guarantees profit.
