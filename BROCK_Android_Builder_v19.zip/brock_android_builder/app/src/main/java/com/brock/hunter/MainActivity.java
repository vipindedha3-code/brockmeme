package com.brock.hunter;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean pageReady = false;
    private String pendingDeepLink = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 11, 16));
        getWindow().setNavigationBarColor(Color.rgb(8, 11, 16));

        Uri startData = getIntent() != null ? getIntent().getData() : null;
        if (startData != null) pendingDeepLink = startData.toString();

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        if (android.os.Build.VERSION.SDK_INT >= 16) {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            private boolean external(String url) {
                return url.startsWith("https://jup.ag/") ||
                       url.startsWith("https://dexscreener.com/") ||
                       url.startsWith("https://solscan.io/") ||
                       url.startsWith("https://phantom.app/ul/") ||
                       url.startsWith("https://phantom.com/ul/") ||
                       url.startsWith("phantom://");
            }

            private boolean handle(String url) {
                if (url.startsWith("brockhunter://phantom-connect")) {
                    dispatchDeepLink(url);
                    return true;
                }
                if (external(url)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) { return handle(url); }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handle(request.getUrl().toString());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingDeepLink != null) {
                    String link = pendingDeepLink;
                    pendingDeepLink = null;
                    dispatchDeepLink(link);
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void dispatchDeepLink(String url) {
        if (url == null) return;
        if (!pageReady || webView == null) { pendingDeepLink = url; return; }
        final String js = "if(window.handlePhantomRedirect){handlePhantomRedirect(" + JSONObject.quote(url) + ");}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pageReady && webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript(
                "if(window.brockAppResumed){window.brockAppResumed();}", null), 700);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri data = intent != null ? intent.getData() : null;
        if (data != null) dispatchDeepLink(data.toString());
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
