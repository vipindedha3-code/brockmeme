BROCK Hunter v23 - STALE-SAFE EXECUTION

Real-only Phantom/Jupiter Android build.

Key v23 change:
- Tracks Jupiter lastValidBlockHeight for each prepared Phantom signing request.
- A watchdog checks pending approval state while BROCK is foregrounded.
- An abandoned request is NOT cleared merely because time passed; BROCK prefers confirming the prepared transaction blockhash has expired.
- If block-height lookup is unavailable, a conservative ~165 second fallback timeout is used.
- Once safely expired, BROCK clears only the stale local pending slot and automatically continues with the newest current PASS candidate.
- No duplicate live order is opened while an earlier transaction can still be valid.
- Phantom approval/signature is still mandatory for every real trade.
- BROCK never receives the wallet seed phrase or private signing key.
- No paper trading and no profit guarantee.
