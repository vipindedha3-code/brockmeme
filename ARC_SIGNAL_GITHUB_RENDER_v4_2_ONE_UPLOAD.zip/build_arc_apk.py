"""ARC Signal v4.2 official Android build for Render."""
import os, pathlib, shutil, subprocess, tarfile, urllib.request, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
TMP=pathlib.Path('/tmp/arc-v42-build')
TMP.mkdir(parents=True,exist_ok=True)
def download(urls,name):
 target=TMP/name
 for url in urls:
  try:
   print('Downloading',url,flush=True)
   req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
   with urllib.request.urlopen(req,timeout=180) as r,open(target,'wb') as f: shutil.copyfileobj(r,f)
   if target.stat().st_size<100000: raise RuntimeError('Too small')
   return target
  except Exception as e:
   print('Download source failed:',e,flush=True)
   target.unlink(missing_ok=True)
 raise RuntimeError('Unable to download '+name)
jdk=TMP/'jdk';jdk.mkdir(exist_ok=True)
with tarfile.open(download(['https://download.oracle.com/java/17/latest/jdk-17_linux-x64_bin.tar.gz','https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse'],'jdk.tar.gz')) as tf: tf.extractall(jdk,filter='data')
java_home=next(x for x in jdk.iterdir() if (x/'bin/java').exists())
sdk=TMP/'android-sdk'
with zipfile.ZipFile(download(['https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip'],'android-tools.zip')) as z: z.extractall(sdk/'cmdline-tools')
(sdk/'cmdline-tools/cmdline-tools').rename(sdk/'cmdline-tools/latest')
with zipfile.ZipFile(download(['https://services.gradle.org/distributions/gradle-8.10.2-bin.zip','https://downloads.gradle.org/distributions/gradle-8.10.2-bin.zip'],'gradle.zip')) as z: z.extractall(TMP)
env=dict(os.environ,JAVA_HOME=str(java_home),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk))
env['PATH']=':'.join([str(java_home/'bin'),str(sdk/'cmdline-tools/latest/bin'),env.get('PATH','')])
manager=str(sdk/'cmdline-tools/latest/bin/sdkmanager')
subprocess.run(['bash','-c','yes | sdkmanager --licenses >/dev/null 2>&1 || true'],env=env,check=True)
subprocess.run([manager,'platform-tools','platforms;android-35','build-tools;35.0.0'],env=env,check=True)
subprocess.run([str(TMP/'gradle-8.10.2/bin/gradle'),'--no-daemon','--console=plain',':app:assembleDebug'],cwd=ROOT,env=env,check=True)
apk=ROOT/'app/build/outputs/apk/debug/app-debug.apk'
subprocess.run([str(sdk/'build-tools/35.0.0/apksigner'),'verify','--verbose',str(apk)],env=env,check=True)
output=ROOT/'public/ARC_SIGNAL_V4_2.apk';output.parent.mkdir(exist_ok=True)
shutil.copyfile(apk,output)
print('Verified APK ready:',output,output.stat().st_size,flush=True)
