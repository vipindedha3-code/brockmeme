package com.arcusdt.signal.multicoin;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.net.Uri;

public class MainActivity extends Activity {
  private WebView web;
  private static final String URL="https://arc-signal-v41-multicoin.onrender.com/";
  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    web=new WebView(this); web.setBackgroundColor(Color.rgb(9,13,24));
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req){
        Uri u=req.getUrl();return !"https".equals(u.getScheme()) || !"arc-signal-v41-multicoin.onrender.com".equals(u.getHost());
      }
      @Override public void onReceivedError(WebView v, android.webkit.WebResourceRequest req, android.webkit.WebResourceError err){
        if(req.isForMainFrame()) v.loadData("<html><body style='background:#090d18;color:white;font-family:sans-serif;padding:25px'><h2>Connection unavailable</h2><p>Check internet access, then reopen ARC SIGNAL.</p></body></html>","text/html","UTF-8");
      }
    });
    setContentView(web);
    web.loadUrl(URL);
  }
  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
