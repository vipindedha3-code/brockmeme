ARC SIGNAL V4.1 - Android APK build
This package contains a real Android WebView project that loads the deployed V4.1 app.
It does not contain an APK until GitHub Actions completes successfully.

UPLOAD TO GITHUB:
1. Extract ZIP on your device.
2. Upload the folder arc_signal_android and the .github/workflows/build-arc-signal-v41-apk.yml file into vipindedha3-code/brockmeme main branch, preserving folder structure.
3. GitHub -> Actions -> Build ARC SIGNAL V4.1 Android APK -> Run workflow.
4. Download the ARC_SIGNAL_V4_1_MultiCoin_APK artifact, unzip, and install app-debug.apk.

Requires internet while using the app. The WebView opens the live https://arc-signal-v41-multicoin.onrender.com/ backend.
APK is a debug build for personal testing, not a Play Store release. Do not enter exchange API secrets into it.
