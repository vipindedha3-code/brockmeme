#!/usr/bin/env python3
import os
import json
import time
import threading
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DEX = "https://api.dexscreener.com"
RPC = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
BOT = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT = os.getenv("TELEGRAM_CHAT_ID", "5610595065")
INTERVAL = int(os.getenv("SCAN_INTERVAL_SECONDS", "60"))
ALERT_SCORE = float(os.getenv("ALERT_SCORE", "70"))
WATCH_SCORE = float(os.getenv("WATCH_SCORE", "70"))
PORT = int(os.getenv("PORT", "10000"))
UA = "BROCK-Meme-Hunter/2.0"

WHALE_ENABLED = os.getenv("WHALE_ENABLED", "1").lower() not in ("0", "false", "no")
WHALE_MIN_BUY_USD = float(os.getenv("WHALE_MIN_BUY_USD", "1000"))
WHALE_WINDOW_SECONDS = int(os.getenv("WHALE_WINDOW_SECONDS", "900"))
WHALE_POLL_PER_SCAN = int(os.getenv("WHALE_POLL_PER_SCAN", "6"))
WHALE_MAX_TRACKED = int(os.getenv("WHALE_MAX_TRACKED", "40"))
MANUAL_WHALES = {
    x.strip() for x in os.getenv("WHALE_WALLETS", "").split(",") if x.strip()
}

SYSTEM_PROGRAM = "11111111111111111111111111111111"
WSOL = "So11111111111111111111111111111111111111112"
USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
USDT = "Es9vMFrzaCERmJfrF4H2FYDZYVNUFhH1R3v6hZ7XQx4"
SPEND_MINTS = {WSOL, USDC, USDT}

seen_alerts = {}
risk_cache = {}
recent_tokens = {}
wallet_hits = {w: 99 for w in MANUAL_WHALES}
tracked_wallets = set(MANUAL_WHALES)
wallet_last_sig = {}
whale_events = {}
wallet_cursor = 0
discovery_cursor = 0
lock = threading.Lock()


def num(v, default=0.0):
    try:
        return float(v)
    except Exception:
        return default


def http_json(url, method="GET", payload=None, timeout=18, retries=2):
    body = None if payload is None else json.dumps(payload).encode()
    last = None
    for attempt in range(retries + 1):
        try:
            req = Request(
                url,
                data=body,
                method=method,
                headers={
                    "User-Agent": UA,
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                },
            )
            with urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode())
        except HTTPError as e:
            last = e
            if e.code == 429 and attempt < retries:
                time.sleep(1.5 * (2 ** attempt))
                continue
            raise
        except (URLError, TimeoutError) as e:
            last = e
            if attempt < retries:
                time.sleep(1.0 * (attempt + 1))
                continue
            raise
    raise last


def rpc(method, params):
    res = http_json(
        RPC,
        "POST",
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params},
        retries=1,
    )
    if res.get("error"):
        raise RuntimeError(str(res["error"]))
    return res.get("result")


def telegram(text):
    if not BOT or not CHAT:
        print("Telegram not configured.", flush=True)
        return False
    try:
        http_json(
            f"https://api.telegram.org/bot{BOT}/sendMessage",
            "POST",
            {"chat_id": CHAT, "text": text, "disable_web_page_preview": True},
            retries=1,
        )
        return True
    except Exception as e:
        print("Telegram warning:", e, flush=True)
        return False


def discover_tokens():
    global discovery_cursor
    endpoints = (
        "/token-profiles/latest/v1",
        "/token-boosts/latest/v1",
        "/community-takeovers/latest/v1",
    )
    endpoint = endpoints[discovery_cursor % len(endpoints)]
    discovery_cursor += 1
    now = time.time()
    try:
        rows = http_json(DEX + endpoint, retries=2)
        if isinstance(rows, dict):
            rows = [rows]
        for row in rows[:120]:
            if str(row.get("chainId", "")).lower() != "solana":
                continue
            mint = row.get("tokenAddress")
            if mint:
                recent_tokens[mint] = now
    except Exception as e:
        print("Discovery warning:", e, flush=True)

    for mint, ts in list(recent_tokens.items()):
        if now - ts > 20 * 60:
            recent_tokens.pop(mint, None)
    return list(recent_tokens.keys())[:80]


def get_pairs(mint):
    try:
        rows = http_json(f"{DEX}/token-pairs/v1/solana/{mint}", retries=1)
        return rows if isinstance(rows, list) else []
    except Exception:
        return []


def best_pair(mint):
    pairs = get_pairs(mint)
    if not pairs:
        return None
    return max(pairs, key=lambda p: num((p.get("liquidity") or {}).get("usd")))


def onchain_risk(mint):
    now = time.time()
    cached = risk_cache.get(mint)
    if cached and now - cached[0] < 600:
        return cached[1]

    out = {
        "ok": False,
        "mint_authority": None,
        "freeze_authority": None,
        "top1": None,
        "top5": None,
    }
    try:
        info = rpc("getAccountInfo", [mint, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        value = (info or {}).get("value") or {}
        parsed = (((value.get("data") or {}).get("parsed") or {}).get("info") or {})
        out["mint_authority"] = parsed.get("mintAuthority")
        out["freeze_authority"] = parsed.get("freezeAuthority")

        supply_res = rpc("getTokenSupply", [mint, {"commitment": "confirmed"}])
        supply = num(((supply_res or {}).get("value") or {}).get("amount"))
        largest = rpc("getTokenLargestAccounts", [mint, {"commitment": "confirmed"}])
        vals = (largest or {}).get("value") or []
        if supply > 0 and vals:
            pcts = [100 * num(x.get("amount")) / supply for x in vals]
            out["top1"] = pcts[0]
            out["top5"] = sum(pcts[:5])
        out["ok"] = True
    except Exception as e:
        out["error"] = str(e)

    risk_cache[mint] = (now, out)
    return out


def evaluate(mint, pair):
    liq = num((pair.get("liquidity") or {}).get("usd"))
    mc = num(pair.get("marketCap")) or num(pair.get("fdv"))
    created = num(pair.get("pairCreatedAt"))
    age = (time.time() * 1000 - created) / 60000 if created else 999999
    tx5 = ((pair.get("txns") or {}).get("m5") or {})
    buys = int(tx5.get("buys") or 0)
    sells = int(tx5.get("sells") or 0)
    ratio = buys / max(1, sells)
    volume5 = num((pair.get("volume") or {}).get("m5"))
    price5 = num((pair.get("priceChange") or {}).get("m5"))
    liq_mc = 100 * liq / mc if mc else 0

    reject = []
    score = 0
    strengths = []
    warnings = []

    if not 2 <= age <= 360:
        reject.append("age outside target")
    if not 25000 <= mc <= 3000000:
        reject.append("market cap outside target")
    if liq < 15000:
        reject.append("liquidity too low")
    if liq_mc < 4:
        reject.append("weak liquidity/market-cap ratio")

    # Only spend RPC calls on coins that already pass basic market filters.
    risk = {"ok": False, "mint_authority": None, "freeze_authority": None, "top1": None, "top5": None}
    if not reject:
        risk = onchain_risk(mint)
        if risk["ok"]:
            if risk["mint_authority"]:
                reject.append("mint authority active")
            if risk["freeze_authority"]:
                reject.append("freeze authority active")
            if not risk["mint_authority"] and not risk["freeze_authority"]:
                score += 12
                strengths.append("mint/freeze authority disabled")
            if risk["top1"] is not None:
                if risk["top1"] <= 8:
                    score += 8
                    strengths.append("healthy top-holder concentration")
                elif risk["top1"] > 18:
                    score -= 6
                    warnings.append("high top-holder concentration")
        else:
            warnings.append("on-chain check unavailable")
            score -= 5

    if 7 <= age <= 120:
        score += 14
        strengths.append("early launch age")
    else:
        score += 5
    if 50000 <= mc <= 750000:
        score += 14
        strengths.append("early market-cap zone")
    else:
        score += 5
    score += 12 if liq >= 80000 else (9 if liq >= 30000 else 5)
    if liq_mc >= 15:
        score += 12
        strengths.append("strong liquidity/MC")
    elif liq_mc >= 8:
        score += 8
    else:
        score += 3
    if 1.25 <= ratio <= 3.5:
        score += 14
        strengths.append("healthy buy pressure")
    elif ratio > 1:
        score += 7
    tx_total = buys + sells
    if tx_total >= 80:
        score += 12
        strengths.append("strong 5m transactions")
    elif tx_total >= 30:
        score += 7
    if volume5 >= 5000:
        score += 7
    if liq and volume5 / liq >= 0.50:
        score += 6
        strengths.append("strong volume/liquidity")
    if mc and volume5 / mc >= 0.12:
        score += 5
    if 2 <= price5 <= 45:
        score += 5
    elif price5 > 80:
        score -= 8
        warnings.append("possible chase pump")
    score = max(0, min(100, round(score, 1)))

    return {
        "mint": mint,
        "score": score,
        "reject": reject,
        "strengths": strengths,
        "warnings": warnings,
        "age": age,
        "mc": mc,
        "liq": liq,
        "liq_mc": liq_mc,
        "buys": buys,
        "sells": sells,
        "ratio": ratio,
        "volume5": volume5,
        "price5": price5,
        "risk": risk,
        "url": pair.get("url", ""),
        "symbol": ((pair.get("baseToken") or {}).get("symbol") or "?"),
        "name": ((pair.get("baseToken") or {}).get("name") or "Unknown"),
    }


def make_alert(c):
    r = c["risk"]
    top1 = "n/a" if r.get("top1") is None else f"{r['top1']:.1f}%"
    strengths = ", ".join(c["strengths"][:5]) or "balanced signal"
    warnings = ", ".join(c["warnings"][:3]) or "none"
    tier = "HIGH" if c["score"] >= 82 else "WATCH"
    return (
        "BROCK MEME HUNTER\n\n"
        f"{tier} POTENTIAL - {c['score']}/100\n"
        f"{c['name']} ({c['symbol']})\n\n"
        f"Age: {c['age']:.0f}m\n"
        f"Market Cap: ${c['mc']:,.0f}\n"
        f"Liquidity: ${c['liq']:,.0f}\n"
        f"Liquidity/MC: {c['liq_mc']:.1f}%\n"
        f"5m Volume: ${c['volume5']:,.0f}\n"
        f"Buys/Sells: {c['buys']}/{c['sells']} ({c['ratio']:.2f}x)\n"
        f"5m Price: {c['price5']:+.1f}%\n"
        f"Top holder: {top1}\n\n"
        f"Strengths: {strengths}\n"
        f"Warnings: {warnings}\n\n"
        f"Contract:\n{c['mint']}\n\n"
        f"DEX Screener:\n{c['url']}"
    )


def is_regular_wallet(address):
    try:
        info = rpc("getAccountInfo", [address, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        value = (info or {}).get("value") or {}
        return value.get("owner") == SYSTEM_PROGRAM and not value.get("executable", False)
    except Exception:
        return False


def learn_whales_from_token(mint):
    if not WHALE_ENABLED or len(tracked_wallets) >= WHALE_MAX_TRACKED:
        return
    try:
        largest = rpc("getTokenLargestAccounts", [mint, {"commitment": "confirmed"}])
        accounts = [x.get("address") for x in ((largest or {}).get("value") or [])[:8] if x.get("address")]
        if not accounts:
            return
        infos = rpc("getMultipleAccounts", [accounts, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        values = (infos or {}).get("value") or []
        owners = []
        for value in values:
            parsed = ((((value or {}).get("data") or {}).get("parsed") or {}).get("info") or {})
            owner = parsed.get("owner")
            if owner:
                owners.append(owner)

        for owner in owners:
            if owner in MANUAL_WHALES:
                tracked_wallets.add(owner)
                continue
            wallet_hits[owner] = wallet_hits.get(owner, 0) + 1
            if wallet_hits[owner] >= 2 and owner not in tracked_wallets:
                if is_regular_wallet(owner):
                    tracked_wallets.add(owner)
                    print(f"WHALE LEARNED {short_wallet(owner)} hits={wallet_hits[owner]}", flush=True)
                    if len(tracked_wallets) >= WHALE_MAX_TRACKED:
                        break
    except Exception as e:
        print("Whale learning warning:", e, flush=True)


def short_wallet(wallet):
    return wallet if len(wallet) < 12 else wallet[:5] + "..." + wallet[-4:]


def token_amount(tb):
    ui = (tb.get("uiTokenAmount") or {})
    if ui.get("uiAmountString") is not None:
        return num(ui.get("uiAmountString"))
    amount = num(ui.get("amount"))
    decimals = int(ui.get("decimals") or 0)
    return amount / (10 ** decimals) if decimals >= 0 else amount


def transaction_wallet_deltas(tx, wallet):
    meta = tx.get("meta") or {}
    transaction = tx.get("transaction") or {}
    message = transaction.get("message") or {}
    keys_raw = message.get("accountKeys") or []
    keys = []
    for k in keys_raw:
        if isinstance(k, str):
            keys.append(k)
        elif isinstance(k, dict):
            keys.append(k.get("pubkey"))
        else:
            keys.append(None)

    sol_delta = 0.0
    try:
        idx = keys.index(wallet)
        pre = (meta.get("preBalances") or [])[idx]
        post = (meta.get("postBalances") or [])[idx]
        sol_delta = (post - pre) / 1e9
    except Exception:
        pass

    pre_map = {}
    post_map = {}
    for tb in meta.get("preTokenBalances") or []:
        if tb.get("owner") == wallet and tb.get("mint"):
            pre_map[tb["mint"]] = pre_map.get(tb["mint"], 0.0) + token_amount(tb)
    for tb in meta.get("postTokenBalances") or []:
        if tb.get("owner") == wallet and tb.get("mint"):
            post_map[tb["mint"]] = post_map.get(tb["mint"], 0.0) + token_amount(tb)

    deltas = {m: post_map.get(m, 0.0) - pre_map.get(m, 0.0) for m in set(pre_map) | set(post_map)}
    logs = " ".join(meta.get("logMessages") or []).lower()
    has_swap_log = "swap" in logs
    spend_token = any(deltas.get(m, 0.0) < 0 for m in SPEND_MINTS)
    spent = sol_delta < -0.001 or spend_token
    buys = [(m, d) for m, d in deltas.items() if d > 0 and m not in SPEND_MINTS]
    return buys, spent, has_swap_log, sol_delta


def record_whale_event(mint, wallet, usd_value):
    now = time.time()
    arr = whale_events.setdefault(mint, [])
    arr.append((now, wallet, usd_value))
    whale_events[mint] = [x for x in arr if now - x[0] <= WHALE_WINDOW_SECONDS]
    unique = {x[1] for x in whale_events[mint]}
    total = sum(x[2] for x in whale_events[mint])
    return len(unique), total


def whale_alert(wallet, mint, amount, pair, usd_value, multi_count, combined_usd, learned_hits):
    name = ((pair.get("baseToken") or {}).get("name") or "Unknown")
    symbol = ((pair.get("baseToken") or {}).get("symbol") or "?")
    liq = num((pair.get("liquidity") or {}).get("usd"))
    mc = num(pair.get("marketCap")) or num(pair.get("fdv"))
    url = pair.get("url", "")
    wallet_type = "MANUAL" if wallet in MANUAL_WHALES else f"LEARNED x{learned_hits}"
    cluster = ""
    if multi_count >= 2:
        cluster = f"\nMULTI-WHALE: {multi_count} wallets / ~${combined_usd:,.0f} in {WHALE_WINDOW_SECONDS // 60}m\n"
    return (
        "BROCK WHALE FOLLOW\n\n"
        f"WHALE BUY DETECTED - {wallet_type}\n"
        f"Wallet: {short_wallet(wallet)}\n"
        f"Token: {name} ({symbol})\n"
        f"Estimated buy value: ~${usd_value:,.0f}\n"
        f"Token received: {amount:,.4g}\n"
        f"Liquidity: ${liq:,.0f}\n"
        f"Market Cap: ${mc:,.0f}\n"
        f"{cluster}\n"
        f"Contract:\n{mint}\n\n"
        f"DEX Screener:\n{url}\n\n"
        "Whale activity is a signal, not a guarantee. Verify before trading."
    )


def process_whale_signature(wallet, signature):
    try:
        tx = rpc("getTransaction", [
            signature,
            {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0, "commitment": "confirmed"},
        ])
        if not tx or (tx.get("meta") or {}).get("err"):
            return
        buys, spent, has_swap, _ = transaction_wallet_deltas(tx, wallet)
        if not buys or not (spent or has_swap):
            return

        for mint, amount in buys[:3]:
            pair = best_pair(mint)
            if not pair:
                continue
            liq = num((pair.get("liquidity") or {}).get("usd"))
            mc = num(pair.get("marketCap")) or num(pair.get("fdv"))
            if liq < 15000 or (mc and mc > 5000000):
                continue
            price = num(pair.get("priceUsd"))
            usd_value = amount * price if price > 0 else 0
            if usd_value < WHALE_MIN_BUY_USD:
                continue

            risk = onchain_risk(mint)
            if risk.get("ok") and (risk.get("mint_authority") or risk.get("freeze_authority")):
                continue

            multi_count, combined = record_whale_event(mint, wallet, usd_value)
            msg = whale_alert(
                wallet,
                mint,
                amount,
                pair,
                usd_value,
                multi_count,
                combined,
                wallet_hits.get(wallet, 0),
            )
            telegram(msg)
            print(
                f"WHALE BUY {short_wallet(wallet)} {((pair.get('baseToken') or {}).get('symbol') or '?')} ~${usd_value:,.0f}",
                flush=True,
            )
    except Exception as e:
        print("Whale tx warning:", short_wallet(wallet), e, flush=True)


def poll_whales():
    global wallet_cursor
    if not WHALE_ENABLED:
        return
    wallets = sorted(tracked_wallets)
    if not wallets:
        return
    count = min(WHALE_POLL_PER_SCAN, len(wallets))
    chosen = [wallets[(wallet_cursor + i) % len(wallets)] for i in range(count)]
    wallet_cursor = (wallet_cursor + count) % len(wallets)

    for wallet in chosen:
        try:
            sigs = rpc("getSignaturesForAddress", [wallet, {"limit": 6, "commitment": "confirmed"}]) or []
            if not sigs:
                continue
            newest = sigs[0].get("signature")
            previous = wallet_last_sig.get(wallet)
            if previous is None:
                wallet_last_sig[wallet] = newest
                continue
            new_items = []
            for item in sigs:
                sig = item.get("signature")
                if sig == previous:
                    break
                if sig:
                    new_items.append(sig)
            wallet_last_sig[wallet] = newest
            for sig in reversed(new_items[:4]):
                process_whale_signature(wallet, sig)
        except Exception as e:
            print("Whale poll warning:", short_wallet(wallet), e, flush=True)


def scan_once():
    tokens = discover_tokens()
    print(f"Discovered/cache {len(tokens)} Solana token(s) | whales={len(tracked_wallets)}", flush=True)

    candidates = []
    for mint in tokens[:50]:
        pair = best_pair(mint)
        if pair:
            candidates.append((mint, pair))
        time.sleep(0.03)

    candidates.sort(key=lambda x: num((x[1].get("volume") or {}).get("m5")), reverse=True)

    for mint, pair in candidates[:24]:
        c = evaluate(mint, pair)
        status = "REJECT" if c["reject"] else ("HIGH" if c["score"] >= 82 else ("WATCH" if c["score"] >= WATCH_SCORE else "IGNORE"))
        print(f"{status:<6} {c['score']:>5} {c['symbol']:<12} age={c['age']:.0f}m liq=${c['liq']:,.0f}", flush=True)

        if not c["reject"] and c["score"] >= 82:
            learn_whales_from_token(mint)

        if c["reject"] or c["score"] < ALERT_SCORE:
            continue
        last = seen_alerts.get(mint, 0)
        if time.time() - last < 1800:
            continue
        seen_alerts[mint] = time.time()
        telegram(make_alert(c))

    poll_whales()


class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = (
            f"BROCK Meme Hunter v2.0 running | whales={len(tracked_wallets)} | manual={len(MANUAL_WHALES)}\n"
        ).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


def run_health_server():
    ThreadingHTTPServer(("0.0.0.0", PORT), HealthHandler).serve_forever()


def main():
    threading.Thread(target=run_health_server, daemon=True).start()
    print(
        f"BROCK Meme Hunter v2.0 started | alert-only | whale-follow={WHALE_ENABLED} | manual-whales={len(MANUAL_WHALES)}",
        flush=True,
    )
    while True:
        started = time.time()
        try:
            scan_once()
        except Exception as e:
            print("Scan error:", repr(e), flush=True)
        time.sleep(max(5, INTERVAL - (time.time() - started)))


if __name__ == "__main__":
    main()
