import os, uuid, time, threading
from typing import Dict, Any
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="ROOT Cloud", version="2.1")
TASKS: Dict[str, Dict[str, Any]] = {}

class TaskIn(BaseModel):
    objective: str
    mode: str = "deep"
    memory: str = ""


def provider():
    base = os.getenv("ROOT_LLM_BASE", "").rstrip("/")
    model = os.getenv("ROOT_LLM_MODEL", "")
    key = os.getenv("ROOT_LLM_API_KEY", "")
    if not (base and model and key):
        raise RuntimeError("ROOT Cloud AI provider is not configured")
    if not base.endswith("/chat/completions"):
        base += "/chat/completions"
    return base, model, key


def ask(system: str, user: str) -> str:
    base, model, key = provider()
    with httpx.Client(timeout=120) as c:
        r = c.post(base, headers={"Authorization": f"Bearer {key}"}, json={
            "model": model,
            "temperature": 0.35,
            "messages": [{"role":"system","content":system},{"role":"user","content":user}],
        })
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


def run_task(tid: str, data: TaskIn):
    t = TASKS[tid]
    try:
        t["status"] = "running"; t["stage"] = "planner"
        ctx = f"\nDurable memory:\n{data.memory}" if data.memory else ""
        plan = ask("You are ROOT Planner. Make an executable plan, evidence requirements, dependencies, and stop conditions. Do not claim external actions."+ctx, data.objective)
        t["stage"] = "parallel_specialists"
        results = {}
        def run(name, system, user):
            try: results[name] = ask(system+ctx, user)
            except Exception as e: results[name] = f"ERROR: {e}"
        jobs = [
            ("research", "You are ROOT Researcher. Identify what is known, unknown, and what requires evidence. Never invent sources.", f"Objective:\n{data.objective}\nPlan:\n{plan}"),
            ("builder", "You are ROOT Builder. Produce the strongest practical solution while marking uncertainty.", f"Objective:\n{data.objective}\nPlan:\n{plan}"),
            ("verifier", "You are ROOT Verifier. Check factual support, missing evidence, contradictions and unsupported assumptions.", f"Objective:\n{data.objective}\nPlan:\n{plan}"),
            ("critic", "You are ROOT Skeptic. Try to disprove the proposed approach and identify failure modes.", f"Objective:\n{data.objective}\nPlan:\n{plan}"),
            ("risk", "You are ROOT Risk Manager. Identify downside, irreversible actions, confidence limits and safer alternatives.", f"Objective:\n{data.objective}\nPlan:\n{plan}"),
        ]
        threads=[]
        for name,system,user in jobs:
            th=threading.Thread(target=run,args=(name,system,user)); th.start(); threads.append(th)
        for th in threads: th.join()
        t["stage"] = "final_judge"
        packet = "\n\n".join(f"{k.upper()}:\n{v}" for k,v in results.items())
        final = ask("You are ROOT Final Judge. Resolve disagreements, veto claims that depend on missing critical evidence, and never say an external action was completed unless evidence proves it."+ctx,
                    f"Objective:\n{data.objective}\n\nPlan:\n{plan}\n\nIndependent specialist packet:\n{packet}")
        t.update(status="done", stage="complete", result=final, finished=time.time())
    except Exception as e:
        t.update(status="failed", stage="error", error=str(e), finished=time.time())

@app.get("/health")
def health():
    return {"ok": True, "service": "ROOT Cloud", "provider_configured": bool(os.getenv("ROOT_LLM_API_KEY"))}

@app.post("/v1/tasks")
def create_task(data: TaskIn):
    tid = str(uuid.uuid4())
    TASKS[tid] = {"id": tid, "status": "queued", "stage": "queued", "created": time.time(), "objective": data.objective}
    threading.Thread(target=run_task, args=(tid, data), daemon=True).start()
    return TASKS[tid]

@app.get("/v1/tasks/{tid}")
def get_task(tid: str):
    if tid not in TASKS: raise HTTPException(404, "Task not found")
    return TASKS[tid]
