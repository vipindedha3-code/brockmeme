ROOT v5 Fusion Mesh source bundle. Combines ROOT Recovery Guard, ROOT generative agents, BROCK Hunter v27 strategy agents and BROCK Cognition Mesh. See root_android_builder/README.txt.
