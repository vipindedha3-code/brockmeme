package app.root.agent;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.webkit.*;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import android.speech.tts.TextToSpeech;

import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private static final int VOICE_REQ = 4101;
    private static final int FILE_REQ = 4102;
    private ValueCallback<Uri[]> fileCallback;
    private static final String KEY_ALIAS = "ROOT_SECURE_V1";
    private static final String PREFS = "root_secure";
    private boolean pageReady = false;
    private String pendingDeepLink = null;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5,7,8));
        getWindow().setNavigationBarColor(Color.rgb(5,7,8));
        Uri startData = getIntent() != null ? getIntent().getData() : null;
        if (startData != null) pendingDeepLink = startData.toString();
        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2001);
        tts = new TextToSpeech(this, this);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= 16) {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        }
        webView.addJavascriptInterface(new RootBridge(), "ROOT_NATIVE");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, FILE_REQ);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            private boolean handleUrl(String url) {
                if (url == null) return false;
                if (url.startsWith("rootagent://callback")) { dispatchDeepLink(url); return true; }
                try {
                    Uri u = Uri.parse(url);
                    String scheme = u.getScheme() == null ? "" : u.getScheme();
                    if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme) || "phantom".equals(scheme)) {
                        startActivity(new Intent(Intent.ACTION_VIEW, u)); return true;
                    }
                } catch (Exception ignored) {}
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) { return handleUrl(req.getUrl().toString()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return handleUrl(url); }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingDeepLink != null) { String x = pendingDeepLink; pendingDeepLink = null; dispatchDeepLink(x); }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("root_routines", "ROOT Routines", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault());
    }

    private void js(String script) {
        if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }

    private String encrypt(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv = c.getIV();
        byte[] enc = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv, Base64.NO_WRAP) + "." + Base64.encodeToString(enc, Base64.NO_WRAP);
    }

    private String decrypt(String packed) throws Exception {
        String[] p = packed.split("\\.", 2);
        if (p.length != 2) return "";
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
    }

    private void saveSecretValue(String name, String value) {
        try { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(name, encrypt(value == null ? "" : value)).apply(); }
        catch (Exception e) { throw new RuntimeException(e); }
    }

    private String readSecretValue(String name) {
        try {
            String v = getSharedPreferences(PREFS, MODE_PRIVATE).getString(name, "");
            return v.isEmpty() ? "" : decrypt(v);
        } catch (Exception e) { return ""; }
    }

    private String readAll(InputStream in, int maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n, total = 0;
        while ((n = in.read(buf)) >= 0) {
            int take = Math.min(n, maxBytes - total);
            if (take > 0) out.write(buf, 0, take);
            total += take;
            if (total >= maxBytes) break;
        }
        return out.toString("UTF-8");
    }

    private String ensureChatUrl(String base) {
        String b = base == null ? "" : base.trim();
        if (b.endsWith("/chat/completions")) return b;
        while (b.endsWith("/")) b = b.substring(0, b.length()-1);
        return b + "/chat/completions";
    }

    public class RootBridge {
        @JavascriptInterface public void saveProvider(String base, String model, String apiKey) {
            saveSecretValue("llm_base", base); saveSecretValue("llm_model", model);
            if (apiKey != null && !apiKey.trim().isEmpty()) saveSecretValue("llm_key", apiKey);
            js("window.rootNativeEvent && rootNativeEvent('provider_saved',{});");
        }

        @JavascriptInterface public String providerStatus() {
            try {
                JSONObject o = new JSONObject();
                String base = readSecretValue("llm_base"), model = readSecretValue("llm_model"), key = readSecretValue("llm_key");
                o.put("base", base); o.put("model", model); o.put("hasKey", key != null && !key.isEmpty());
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void clearProvider() {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply();
            js("window.rootNativeEvent && rootNativeEvent('provider_cleared',{});");
        }

        @JavascriptInterface public void aiComplete(String requestId, String messagesJson, String systemPrompt) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    String base = readSecretValue("llm_base"), model = readSecretValue("llm_model"), key = readSecretValue("llm_key");
                    if (base.isEmpty() || model.isEmpty() || key.isEmpty()) throw new Exception("AI provider is not configured in ROOT Settings.");
                    URL url = new URL(ensureChatUrl(base));
                    if (!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("ROOT requires an HTTPS AI endpoint.");
                    HttpURLConnection c = (HttpURLConnection)url.openConnection();
                    c.setConnectTimeout(20000); c.setReadTimeout(120000); c.setRequestMethod("POST"); c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    c.setRequestProperty("Authorization", "Bearer " + key);
                    JSONObject body = new JSONObject(); body.put("model", model); body.put("temperature", 0.35);
                    JSONArray msgs = new JSONArray();
                    if (systemPrompt != null && !systemPrompt.trim().isEmpty()) msgs.put(new JSONObject().put("role","system").put("content",systemPrompt));
                    JSONArray userMsgs = new JSONArray(messagesJson);
                    for (int i=0;i<userMsgs.length();i++) msgs.put(userMsgs.getJSONObject(i));
                    body.put("messages", msgs);
                    byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                    try(OutputStream os=c.getOutputStream()){ os.write(data); }
                    int code = c.getResponseCode();
                    InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                    String raw = readAll(in, 2_000_000);
                    if (code < 200 || code >= 300) throw new Exception("Provider HTTP " + code + ": " + raw);
                    JSONObject response = new JSONObject(raw);
                    String content = response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "");
                    result.put("ok", true); result.put("content", content); result.put("raw", response);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch(Exception ignored){}
                }
                final String payload = JSONObject.quote(result.toString());
                js("window.rootAIResult && rootAIResult(" + JSONObject.quote(requestId) + ",JSON.parse(" + payload + "));" );
            }).start();
        }

        @JavascriptInterface public void fetchUrl(String requestId, String urlString) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    URL url = new URL(urlString);
                    if (!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("Only HTTPS URLs are allowed.");
                    HttpURLConnection c = (HttpURLConnection)url.openConnection();
                    c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("User-Agent", "ROOT-Agent/4.0 Android");
                    c.setInstanceFollowRedirects(true);
                    int code = c.getResponseCode();
                    InputStream in = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
                    String raw = readAll(in, 1_500_000);
                    result.put("ok", code >= 200 && code < 400); result.put("status", code); result.put("body", raw); result.put("url", urlString);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch(Exception ignored){}
                }
                final String payload = JSONObject.quote(result.toString());
                js("window.rootFetchResult && rootFetchResult(" + JSONObject.quote(requestId) + ",JSON.parse(" + payload + "));" );
            }).start();
        }

        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e){ Toast.makeText(MainActivity.this,"Unable to open link",Toast.LENGTH_SHORT).show(); } });
        }

        @JavascriptInterface public void openPhantom(String url) {
            if (url == null || !(url.startsWith("https://phantom.com/") || url.startsWith("https://phantom.app/") || url.startsWith("phantom://"))) return;
            runOnUiThread(() -> {
                try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); i.setPackage("app.phantom"); startActivity(i); }
                catch(Exception e) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored){} }
            });
        }

        @JavascriptInterface public void copyText(String text) {
            android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("ROOT", text));
            runOnUiThread(() -> Toast.makeText(MainActivity.this,"Copied",Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface public void speak(String text) {
            if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "root_tts");
        }

        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ROOT");
                    startActivityForResult(i, VOICE_REQ);
                } catch(Exception e) { Toast.makeText(MainActivity.this,"Voice recognition unavailable",Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface public void scheduleReminder(String id, String title, String body, long whenMillis) {
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            i.putExtra("title", title); i.putExtra("body", body);
            int req = Math.abs((id == null ? "root" : id).hashCode());
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (whenMillis < System.currentTimeMillis()+3000) whenMillis = System.currentTimeMillis()+3000;
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi);
            else am.set(AlarmManager.RTC_WAKEUP, whenMillis, pi);
            js("window.rootNativeEvent && rootNativeEvent('reminder_scheduled',{id:" + JSONObject.quote(id) + "});");
        }

        @JavascriptInterface public String appInfo() {
            try {
                JSONObject o = new JSONObject(); o.put("version","4.0.0"); o.put("android", Build.VERSION.RELEASE); o.put("device", Build.MANUFACTURER+" "+Build.MODEL);
                return o.toString();
            } catch(Exception e){ return "{}"; }
        }
    }

    private void dispatchDeepLink(String url) {
        if (url == null) return;
        if (!pageReady || webView == null) { pendingDeepLink = url; return; }
        js("if(window.handlePhantomRedirect){window.handlePhantomRedirect(" + JSONObject.quote(url) + ");}");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); Uri data = intent != null ? intent.getData() : null;
        if (data != null) dispatchDeepLink(data.toString());
    }

    @Override protected void onResume() {
        super.onResume();
        if (pageReady && webView != null) webView.postDelayed(() -> webView.evaluateJavascript("if(window.rootAppResumed){window.rootAppResumed();}", null), 700);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQ && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) js("window.rootVoiceResult && rootVoiceResult(" + JSONObject.quote(r.get(0)) + ");");
        } else if (requestCode == FILE_REQ && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
