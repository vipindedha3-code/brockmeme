ROOT Android Builder v5 — Fusion Mesh

Adds on top of v4 Recovery Guard:
- BROCK Hunter v27 deterministic strategy agents: HUNT, WHALE, MOMO, VOLT, REV, SHIELD.
- BROCK v27 EDGE, flow, regime, confidence and dominant-agent calculations.
- BROCK Cognition Mesh: Planner, Skeptic, Verifier, Stress and Uncertainty with consensus/veto.
- ROOT + BROCK fusion gate: both deterministic layers must pass before a candidate reaches auto trade assist.
- Fresh BROCK fusion re-evaluation immediately before every real BUY.
- Visible live Fusion Mesh dashboard for the strongest current candidate.
- Existing ROOT generative crypto jury remains the final reasoning layer when an AI provider is configured.
- All v4 wallet reconciliation, persistent locks, stale-pending recovery, signed-transaction retry, exposure caps, trade-frequency limits, loss circuit breakers and partial exits remain.
- Phantom approval is mandatory for every real-money transaction. ROOT never receives the wallet signing key.

Build on Render with build_on_render.sh. Output: public/ROOT-v5.apk
