BROCK Hunter v29 - RECOVERY MESH + COPY MESH

v29 reliability fixes and safeguards:
- Jupiter quote and transaction-build requests retry transient 408/425/429/5xx failures and fail over across supported Jupiter endpoints.
- Protective SELLs no longer inherit the stricter BUY price-impact threshold. Manual/protective exits use dedicated exit limits and still require explicit Phantom approval.
- If a protective exit route is temporarily unavailable, RECOVERY MESH persists an exit retry queue and keeps retrying while the holding remains on-chain. It never creates overlapping Phantom approvals.
- Phantom-signed transactions are retained locally if Solana RPC broadcast fails, then automatically rebroadcast across RPC fallbacks until accepted or the blockhash expires.
- Wallet pricing now attempts executable Jupiter liquidation quotes for untrusted holdings, with USDC then SOL valuation fallback.
- Managed/unpriced positions always remain material UNKNOWN exposure and block new BUYs.
- Non-managed tokens with no executable route/no usable market, or demonstrably tiny low-liquidity estimates, are quarantined instead of freezing all trading. They are excluded from spendable valuation and the wallet total is shown as a lower bound, not falsely treated as exact or as priced $0 exposure.
- Potentially material unpriced holdings still block BUYs.
- Stale position locks require two distinct reliable zero-balance wallet snapshots before release, reducing false unlock/rebuy races.
- FORCE RECONCILE continues to rebuild wallet balances, confirmed swaps, lots, exposure and locks.
- Existing BROCK v28 COPY MESH, HUNT/WHALE/MOMO/VOLT/REV/SHIELD agents, Cognition Mesh, duplicate-buy lock, exposure caps, re-entry cooldown, circuit breakers and one-tap BUY/SELL controls remain.
- No seed phrase or private signing key is stored. Every real transaction still requires Phantom approval.
- No profit guarantee. Illiquid memecoins can gap, rug, become unsellable or lose most/all value despite safeguards.

This is a debug/sideload APK build.
