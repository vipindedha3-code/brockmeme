#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
export ANDROID_SDK_ROOT="$ROOT/.android-sdk"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"

if ! command -v java >/dev/null 2>&1; then
  echo "Java is required in the build environment." >&2
  exit 2
fi
java -version

if [ ! -x "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "Downloading Android command-line tools..."
  curl -fsSL "https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip" -o /tmp/android-tools.zip
  rm -rf /tmp/android-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  mkdir -p /tmp/android-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  unzip -q /tmp/android-tools.zip -d /tmp/android-tools
  cp -R /tmp/android-tools/cmdline-tools/. "$ANDROID_SDK_ROOT/cmdline-tools/latest/"
fi
SDKMANAGER="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
"$SDKMANAGER" "platforms;android-35" "build-tools;35.0.0" "platform-tools"

if [ ! -x "$ROOT/.gradle-dist/gradle-8.9/bin/gradle" ]; then
  echo "Downloading Gradle..."
  mkdir -p "$ROOT/.gradle-dist"
  curl -fsSL "https://services.gradle.org/distributions/gradle-8.9-bin.zip" -o /tmp/gradle.zip
  unzip -q /tmp/gradle.zip -d "$ROOT/.gradle-dist"
fi
export PATH="$ANDROID_SDK_ROOT/platform-tools:$ANDROID_SDK_ROOT/build-tools/35.0.0:$PATH"
"$ROOT/.gradle-dist/gradle-8.9/bin/gradle" --no-daemon --stacktrace assembleDebug
mkdir -p "$ROOT/public"
cp "$ROOT/app/build/outputs/apk/debug/app-debug.apk" "$ROOT/public/BROCK-Hunter-v2.apk"
cat > "$ROOT/public/index.html" <<'HTML'
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:system-ui;background:#080b10;color:#edf6f2;text-align:center;padding:50px 18px}a{display:inline-block;background:#6ee7b7;color:#07100c;text-decoration:none;font-weight:800;padding:14px 20px;border-radius:12px}</style></head><body><h1>BROCK Hunter v2 APK</h1><p>Android build completed successfully.</p><p><a href="/BROCK-Hunter-v2.apk">Download APK</a></p></body></html>
HTML
sha256sum "$ROOT/public/BROCK-Hunter-v2.apk" | tee "$ROOT/public/SHA256.txt"
