BROCK Hunter v4 - Phantom Connected

Features:
- Phantom mobile wallet connection via Phantom universal link/deeplink approval flow
- End-to-end encrypted Phantom connect response using TweetNaCl in the app WebView
- Public wallet address auto-filled only after the user approves in Phantom
- Reads public SOL balance and non-zero SPL/Token-2022 holdings from Solana RPC
- Guarded Live Assist risk gates remain in place before opening a trade
- Jupiter/Phantom still require the user to review and sign the real transaction
- BROCK never asks for or stores a seed phrase or wallet private key
- Phantom session/encryption keys are app-session credentials, not wallet signing keys
- Paper Survival Mode and adaptive strategy agents remain available

Security:
Never enter a Phantom recovery phrase or private key into BROCK. The connection should be approved only inside the official Phantom app.

This app does not guarantee profitability. Meme coins are highly speculative and can lose most or all value.
