ARC SIGNAL V4.1 complete GitHub Android project.
IMPORTANT: GitHub does NOT unpack uploaded ZIP files automatically.
Extract this ZIP on your device, then upload the CONTENTS (including hidden .github folder) to repository root.
GitHub Actions builds the debug APK and makes it available in the successful run Artifacts section.
This app displays the Render web application and requires internet access.
