BROCK Hunter v5 - Real Phantom Wallet View

Changes from v4:
- Fixes the top balance card so it no longer keeps showing virtual USDT after Phantom connects.
- Connected + refreshed Phantom wallet becomes the primary top-left balance view.
- Shows native SOL plus an approximate USD wallet value when reliable public DEX prices are available.
- SPL token holdings are read from public Solana account data; low-liquidity/unpriced tokens are not trusted for the wallet value estimate.
- Paper P&L, win rate and exposure are clearly labelled PAPER and remain separate from the real wallet.
- Phantom retains all signing keys. BROCK never asks for or stores a seed phrase/private key.
- Real transactions still require external wallet review and approval.

Build on Render using build_on_render.sh. Output: public/BROCK-Hunter-v5.apk
