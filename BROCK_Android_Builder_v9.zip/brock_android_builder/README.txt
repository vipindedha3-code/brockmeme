BROCK Hunter v9 - Real Phantom Wallet Tracker + TRILLION Strategy Lab

New in v9:
- Connected Phantom wallet is treated as the real-money account view.
- Reads public on-chain SOL, SPL Token and Token-2022 balances.
- Estimates current USD wallet value from available market prices; stablecoins are valued at $1.
- Shows REAL WALLET P&L from a local wallet-value baseline.
- Automatically refreshes the real wallet while the app is open and after returning from Phantom/Jupiter.
- RESET REAL P&L BASELINE is provided for deposits, withdrawals, or when starting a new measurement period.
- Top balance card switches from paper balance to REAL PHANTOM WALLET after connection/refresh.
- Paper P&L, win rate and exposure remain clearly separate from real-money wallet metrics.
- Manual daily P&L remains only for the user-controlled safety loss-lock.
- Existing TRILLION Strategy Lab, walk-forward optimizer, Adaptive EDGE, precision gate, guarded Live Assist and risk-at-stop sizing retained.

Important:
- BROCK never receives or stores a seed phrase/private key.
- Real wallet USD value is an estimate derived from public blockchain balances and external market prices, so it can differ from Phantom's own USD display.
- Deposits/withdrawals alter wallet value and therefore baseline P&L unless the baseline is reset.
- No strategy can guarantee profit. Every real transaction still requires Phantom/Jupiter confirmation.

Build on Render using build_on_render.sh. Output: public/BROCK-Hunter-v9.apk
