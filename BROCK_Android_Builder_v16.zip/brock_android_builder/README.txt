BROCK Hunter v16 - REAL-ONLY COGNITION MESH

Purpose
- BROCK remains the primary live-account interface after Phantom connects.
- No paper trades are created.
- Adds BROCK Cognition Mesh: a proprietary-to-BROCK reasoning stack built from public multi-agent reasoning ideas, not copied from Claude or Grok internals.

Cognition Mesh
- Planner: forms the opportunity thesis from EDGE, regime, confidence and flow.
- Skeptic: actively attacks the proposed trade for chase, weak liquidity/MC structure, extreme order-flow and fragile safety margins.
- Verifier: checks whether market data is sufficiently complete and liquid before trusting a signal.
- Stress: counterfactual margin test; perturbs core assumptions and rejects setups that only barely pass.
- Uncertainty: measures disagreement/data weakness and can veto a trade even when headline score is high.
- Consensus: combines the independent layers; real candidates must pass both cognition and existing live safety gates.

Real-account behavior
- Main dashboard shows actual on-chain wallet value, real P&L, real win rate and real exposure.
- Real BUY and SELL remain Phantom-confirmed. BROCK never silently signs or moves funds.
- After a confirmed trade, BROCK refreshes wallet holdings and trade history.

Safety
- No method guarantees profit. The cognition layer is designed to increase selectivity and reject fragile setups, not force trades.
- BROCK never requests or stores a seed phrase or wallet private signing key.
- Public RPC/DEX data can be incomplete or rate-limited.

Build
Run build_on_render.sh. Output: public/BROCK-Hunter-v16.apk
