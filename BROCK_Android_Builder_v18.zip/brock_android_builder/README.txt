BROCK Hunter v18 - SOLID EXECUTION CORE

Changes:
- Removes public Solana RPC as the primary real-buy preflight dependency.
- Uses Jupiter Shield first for mint/freeze/sellability/concentration/security warnings.
- Uses Jupiter Tokens V2 as a second independent token-safety source, including authority audit, top-holder percentage, organic score and suspicious-token flag.
- Solana RPC remains only a final fallback for token preflight.
- Candidate discovery is broader: Jupiter recent first-pool tokens + DEX Screener profiles, boosts and community takeovers.
- DEX token data is fetched in batches rather than one-token-at-a-time.
- Real scan cadence defaults to 60 seconds while wallet RPC refresh is decoupled to every fifth scan, reducing 429 pressure.
- Strategy/cognition scores are advisory. A candidate is still surfaced when minimum executable market conditions pass; hard security checks decide whether REAL BUY is enabled.
- No paper mode. Every real BUY/SELL still requires explicit Phantom confirmation.

No strategy guarantees profit. Memecoins can lose most or all of their value.
