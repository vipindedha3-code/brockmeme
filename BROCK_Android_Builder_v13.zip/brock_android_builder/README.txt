BROCK Hunter v13 - BROCK Real Money Account

Purpose
- BROCK is the primary real-money dashboard for the connected Solana wallet.
- Phantom is retained as the signing/approval layer only.
- No virtual USDT appears in the main real-account metrics.

Real account features
- BROCK REAL BALANCE: actual on-chain wallet value (USD is market-price estimate).
- BROCK AVAILABLE TO TRADE: actual liquid SOL + USDC/USDT/WSOL available for the next trade.
- BROCK REAL P&L: reconstructed realized Jupiter P&L + approximate unrealized open-lot P&L when data is available.
- BROCK WIN RATE: reconstructed from recent confirmed Jupiter sell outcomes.
- BROCK EXPOSURE: current priced non-core token exposure.
- BROCK REAL POSITIONS: actual SPL holdings with SELL FROM BROCK controls.
- Confirmed BUY/SELL returns are reconciled after app resume; BROCK shows refreshed available balance and account-value changes in BROCK SETTLEMENT STATUS.
- Real equity history chart tracks wallet refreshes.

Trading architecture
- Scanner candidate -> PREP REAL BUY -> risk/preflight checks -> ARM REAL MONEY MODE -> BUY FROM BROCK -> Jupiter/Phantom confirmation.
- Existing real holding -> SELL FROM BROCK -> Jupiter/Phantom confirmation.
- After confirmation and Solana settlement, BROCK refreshes the wallet and makes resulting liquid SOL/stablecoins visible as BROCK AVAILABLE TO TRADE.
- The underlying assets remain on-chain at the connected wallet address; BROCK is the interface, not a custodial wallet.

Safety and accuracy
- BROCK never requests/stores a seed phrase or private signing key.
- Every real transaction still requires explicit Phantom approval/signature.
- Public RPC and DEX pricing can be rate-limited or incomplete.
- Historical win rate/P&L reconstruction can miss unsupported routes or older transactions.
- Deposits/withdrawals affect wallet equity and baseline-based P&L.
- No strategy can guarantee profit.

Build
Run build_on_render.sh. Output: public/BROCK-Hunter-v13.apk
