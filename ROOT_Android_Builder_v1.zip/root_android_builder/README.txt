ROOT v1 — Android Agent System

Core included in APK:
- Provider-agnostic AI engine using OpenAI-compatible HTTPS chat/completions endpoint
- API key encrypted by Android Keystore (not stored in HTML/localStorage)
- Multi-agent orchestrator: Planner, Researcher, Critic, Builder, Synthesizer
- Deep mode with parallel specialist calls
- Built-in Wikipedia research + secure HTTPS fetch bridge
- Task queue, activity timeline, projects/memory, reusable routines
- Voice input and text-to-speech
- Local scheduled routine reminders
- Explicit approval design for external actions
- Provider settings, model selection, secure key clear

Optional root_cloud folder in the package contains a server-side task runner template for future persistent cloud workers.

No AI provider key is bundled. Configure your own OpenAI-compatible API endpoint, model, and API key in Settings.
