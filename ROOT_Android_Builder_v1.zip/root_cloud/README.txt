ROOT Cloud v1 (optional)

Purpose: run longer agent tasks away from the phone. The Android APK works without this component using the on-device orchestrator + your configured OpenAI-compatible provider.

Environment variables:
ROOT_LLM_BASE=https://provider.example/v1
ROOT_LLM_MODEL=model-name
ROOT_LLM_API_KEY=secret

Start:
uvicorn app:app --host 0.0.0.0 --port $PORT

Security note: set provider credentials as server secrets. Never commit API keys to GitHub.
