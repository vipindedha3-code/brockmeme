import os, uuid, time, threading
from typing import Dict, Any
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="ROOT Cloud", version="1.0")
TASKS: Dict[str, Dict[str, Any]] = {}

class TaskIn(BaseModel):
    objective: str
    mode: str = "deep"
    memory: str = ""


def provider():
    base = os.getenv("ROOT_LLM_BASE", "").rstrip("/")
    model = os.getenv("ROOT_LLM_MODEL", "")
    key = os.getenv("ROOT_LLM_API_KEY", "")
    if not (base and model and key):
        raise RuntimeError("ROOT Cloud AI provider is not configured")
    if not base.endswith("/chat/completions"):
        base += "/chat/completions"
    return base, model, key


def ask(system: str, user: str) -> str:
    base, model, key = provider()
    with httpx.Client(timeout=120) as c:
        r = c.post(base, headers={"Authorization": f"Bearer {key}"}, json={
            "model": model,
            "temperature": 0.35,
            "messages": [{"role":"system","content":system},{"role":"user","content":user}],
        })
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


def run_task(tid: str, data: TaskIn):
    t = TASKS[tid]
    try:
        t["status"] = "running"; t["stage"] = "planner"
        ctx = f"\nDurable memory:\n{data.memory}" if data.memory else ""
        plan = ask("You are ROOT Planner. Make an executable plan; do not claim external actions."+ctx, data.objective)
        t["stage"] = "builder"
        build = ask("You are ROOT Builder. Produce a strong practical solution; mark uncertainty."+ctx, f"Objective:\n{data.objective}\n\nPlan:\n{plan}")
        critic = ""
        if data.mode != "quick":
            t["stage"] = "critic"
            critic = ask("You are ROOT Critic. Find errors, unsupported assumptions, and missing safeguards."+ctx, build)
        t["stage"] = "synthesis"
        final = ask("You are ROOT Synthesizer. Produce the final answer. Never say an external action was completed unless evidence proves it."+ctx,
                    f"Objective:\n{data.objective}\n\nPlan:\n{plan}\n\nDraft:\n{build}\n\nCritique:\n{critic}")
        t.update(status="done", stage="complete", result=final, finished=time.time())
    except Exception as e:
        t.update(status="failed", stage="error", error=str(e), finished=time.time())

@app.get("/health")
def health():
    return {"ok": True, "service": "ROOT Cloud", "provider_configured": bool(os.getenv("ROOT_LLM_API_KEY"))}

@app.post("/v1/tasks")
def create_task(data: TaskIn):
    tid = str(uuid.uuid4())
    TASKS[tid] = {"id": tid, "status": "queued", "stage": "queued", "created": time.time(), "objective": data.objective}
    threading.Thread(target=run_task, args=(tid, data), daemon=True).start()
    return TASKS[tid]

@app.get("/v1/tasks/{tid}")
def get_task(tid: str):
    if tid not in TASKS: raise HTTPException(404, "Task not found")
    return TASKS[tid]
