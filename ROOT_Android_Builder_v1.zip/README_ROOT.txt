ROOT v1 — Full Stack Starter

This package is a new app, separate from BROCK.

Android capabilities:
- polished ROOT agent dashboard
- Quick / Deep / Max multi-agent modes
- Planner, Researcher, Builder, Critic, Synthesizer
- provider-independent OpenAI-compatible AI endpoint
- Android Keystore encryption for provider credentials
- local task vault, durable project memory, activity audit trail
- approval-gated external URL actions
- Wikipedia research tool and secure HTTPS fetch bridge
- voice input and text-to-speech
- local scheduled routine notifications
- local state export

Optional ROOT Cloud:
- background task API scaffold
- server-side agent orchestration
- provider secrets kept server-side

Important:
- No proprietary Grok code, assets, branding, or reverse-engineered binaries are included.
- ROOT does not bundle a large language model in the APK. It uses a provider you configure.
- No API key is bundled.
- ROOT v1 does not silently execute external website/account actions.
